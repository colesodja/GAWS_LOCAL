###### R code to generate some shape anomalies with shifts, rw, mixture of seasonality, high or increasing scale/shape,
# Created by Cole Sodja

###### Load libraries
require(gamlss)

##### Global Arguments
#directory to lookup and store data
dir_out = paste( getwd(), "/data/", sep='')

#maximum length of each time series
n_length = 24*21

##### Read Time Series 
#Random Walk BCCG
M_rw = get( load( paste(dir_out, "/Mat_rw.rda" ,sep='')) )

#Downward Step
M_shift = get( load( paste(dir_out, "/Mat_downward_shift.rda" ,sep='')) )

#Mixture of seasonality, RW, Pulse, Step
M_mix = get( load( paste(dir_out, "/Mat_seas_mix.rda" ,sep='')) )


##### Generate 10 Shape Anomalies
M = matrix(NA, nrow = n_length, ncol = 10)

#white noise extreme scale
M[,1] = rnorm( n_length,  500, .6*500)
M[,1] = ifelse(M[,1]<=0,1,M[,1])

# Simulate BCCG - constant location, increasing linear and log-linear scale, normal shape
M_rw_scale = matrix(NA, nrow = n_length, ncol = 2)
v_b = runif(2, .002, .005)
v_sd = sample(seq(.1,.2,.01),2)

for(j in 1:2){
  z = func.sim.rwd(n_length, v_sd[j],v_b[j] )
  z = ( z -  min(z) )/( max(z) - min(z) )
  
  if( runif(1) <= .6){
    z = log(1+z)
    z = ( z -  min(z) )/( max(z) - min(z) )
  }
  
  z = .05 + runif(1,.25,.75)*z
  M_rw_scale[,j] = z
}

M[,2] = rBCCG( n_length,  500, M_rw_scale[,1], .5)

x = 1:nrow(M)
z = M_rw_scale[,2]
z_p = z[300]
v_scl = ifelse( x<= 300, z, z_p + .5*z**.9)
M[,3] = rBCCG( n_length,  500, v_scl , .3)

# Simulate BCCG - increasing skewness
v_scl = ifelse( x <= 200, .5, ifelse( x <= 300, -.3, -.6) )
v_sig = ifelse( x<=200, .15, .25)
M[,4] = rBCCG( n_length, 500, v_sig, v_scl )

#Simulate BCCG - Location RW
M[,5] = rBCCG( n_length, M_rw[,4], .05, .1)

#Simulate BCCG - Location Downward Shift
M[,6] = rBCCG( n_length, M_shift[,2], .1, .4)
M[,7] = rBCCG( n_length, M_shift[,5], .1, .4)

#Simulate BCCG - large dips
M[,8] = rBCCG( n_length, M_rw[,6], .05, .1)
M[,8][c(100,200,300,400)] = 10

#Simulate BCCG - Mixtures
M[,9] = rBCCG( n_length, M_mix[,2], .1, .5)
M[,9][400:504] = 2000

M[,10] = rBCCG( n_length, M_mix[,8], .1, .5)


### save matrix of shape anomalies
mOut = paste( dir_out, "Mat_anomaly.rda", sep="" )
save(M, file = mOut)

### Generate Plots of Shape Anomalies
A1 = ts(M[,1:10])
colnames(A1) = rep("",10)
plot( A1, col = "red" , main="" , yaxt="n")



