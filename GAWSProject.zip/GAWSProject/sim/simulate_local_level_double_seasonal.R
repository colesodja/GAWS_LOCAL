###### R code to produce sample paths for local level double seasonal models
# Created by Cole Sodja


##### Load GAMLSS Library (assumed installed!)
require(gamlss)


##### Global Parameters
#number of time series to simulate
n_series = 1000

#location and scale initial parameters for truncated log-normal distribution to produce starting levels
l_parm_level_cont = list('location'= log(600), 'scale'= 1.1, 'lower' = 350, 'upper' = 650)

#location and scale initial parameters for truncated log-normal distribution to simulate coefficient of variation
l_parm_cv = list( 'location'  = log(.05), 'scale'  = .15, 'lower' = .001, 'upper' = .2 )

#level smoothing coefficient range
v_smooth_ran = c(0,.15)

#seasonal smoothing coefficients
v_seas_smooth_ran = c(.001,.1)

#day of week average effect, from Mon to Sun
v_dow_mu = c(.27,.25,.24,.21,.12,-.52,-.57) 
v_dow_mu = v_dow_mu - sum(v_dow_mu)

#hour of day average effect via Fourier Basis
l_hour_parm = 
  list(
    v_coef_sine = c(.1,-.2),
    v_coef_cosine = c(-.5,-.2)
  )


#directory to save data
dirOut = paste( getwd(), "/data/", sep='')

#directory to source functions
dirSrc = paste( getwd(), "/src/", sep='')


##### Source Functions
l_list_func = list.files(dirSrc)

for( vfunc  in l_list_func){
  fpath = paste(dirSrc, vfunc, sep='')
  source(fpath)
}


##### Initialize Priors
#starting local level - continuous from truncated log-normal
l0_cont= rLOGNO(n_series, mu = l_parm_level_cont$location, sigma=l_parm_level_cont$scale)
l0_cont = pmax( pmin(l0_cont,l_parm_level_cont$upper),l_parm_level_cont$lower )


#cv error distribution from truncated log-normal
e_cv = rLOGNO(n_series, l_parm_cv$location, l_parm_cv$scale)
e_cv = pmax( l_parm_cv$lower, pmin(e_cv,l_parm_cv$upper))


#level smoothing%
v_smooth = runif(n_series, v_smooth_ran[1], v_smooth_ran[2])

#hour of day effect
v_hour_mu = func.fourier.basis(l_hour_parm,s.period=24)
v_hour_mu = v_hour_mu-mean(v_hour_mu)

#daily and weekly smoothing
v_smooth_dow = runif(n_series, v_seas_smooth_ran[1], v_seas_smooth_ran[2])
v_smooth_hour = runif(n_series, v_seas_smooth_ran[1], v_seas_smooth_ran[2])


######  Simulate from local level with double seasonality 
#create 21*24 time point
d_time = data.frame(Time = seq(21*24))

#add hour of day 
d_time$hour = d_time$Time %% 24
d_time$hour = ifelse(d_time$hour==0,24,d_time$hour)

#add day of week
d_time$dow = 1
dow_prev = 1

for( j in d_time$Time  ){
  x = d_time$hour[j]
  dow_prev = ifelse( x==1 & j>1, dow_prev+1,dow_prev)
  d_time$dow[j]  = dow_prev
}

d_time$dow_seq = d_time$dow
d_time$dow = d_time$dow %% 7
d_time$dow = ifelse(d_time$dow==0,7,d_time$dow)


### loop thru each series 
#dataframe to append time series
d_ts = data.frame()
M_ts = matrix(NA, nrow = 504, ncol = n_series)


## generate univariate time series
for( v in seq(n_series) ){
  print(v)
  l0 = l0_cont[v]
  l0 = log(l0)
  
  #generate standard deviation in innovations
  e_sd = e_cv[v] 
  
  #lookup level smooth%
  l_smooth = v_smooth[v]
  
  #lookup seasonal smooths
  dow_smooth = v_smooth_dow[v]
  hour_smooth = v_smooth_hour[v]
  
  #assign initial seasonalities
  s1_0 = v_dow_mu
  s2_0 = v_hour_mu
  
  #list with parameters
  l_par = list( 'l0' = l0, 'sigma' = e_sd,
                'l_smooth' = l_smooth,
                's1_smooth' = dow_smooth,
                's2_smooth' = hour_smooth,
                's1_period' = 7,
                's2_period' = 24,
                's1_0' = s1_0,
                's2_0'= s2_0
  )
  
  #simulate Gaussian white noise
  e = rnorm(nrow(d_time), 0, e_sd)
  dy = d_time
  dy$e = e
  
  
  #simulate from local_level
  l_level = func.sim.local.level(dy, l_par)
  
  
  #simulate from double seasonal model
  dy$t_s1 = dy$dow
  dy$t_s2 = dy$hour
  dy$s1_seq = dy$dow_seq
  l_seas = func.sim.double.seasonal(dy, l_par)
  
  #add basis
  log_y = l_level$l + l_seas$s1 + l_seas$s2 +e
  
  #transform 
  y.mu = exp(log_y)
  
  #append
  d_mu = dy[,1:5]
  d_mu$y.mu = y.mu 
  d_mu$e = e
  d_mu$ID = paste("local_level_season_",v)
  d_mu$link = "log"
  d_mu$cv = e_sd 
  d_mu$l_smooth = l_smooth
  d_mu$s1_smooth = dow_smooth
  d_mu$s2_smooth = hour_smooth
  d_mu$level = l_level$l
  d_mu$s1 = l_seas$s1
  d_mu$s2 = l_seas$s2
  d_ts = rbind(d_ts, d_mu)
  M_ts[,v] = y.mu
}


##### Save time series to rda file
file.out = paste( dirOut, "d_local_level_seas.rda", sep='' )
save(d_ts, file = file.out)

