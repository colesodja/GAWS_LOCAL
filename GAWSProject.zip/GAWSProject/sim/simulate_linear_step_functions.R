###### R code to simulate sample paths from linear step functions
# Created by Cole Sodja


##### Global Arguments
#directory to save data
dirOut = paste( getwd(), "/data/", sep='')

#rda file of dataframe containing level, assumed on log-scale
fInp = paste( getwd(), "/data/d_local_level_seas.rda", sep='')

#full path to output dataframe to rda file
fOut = paste( getwd(), "/data/d_shift.rda", sep='')

#directory to source functions
dirSrc = paste( getwd(), "/src/", sep='')

#start and end index where shift can occur
vshiftRan = c(50,450)

#range of lower and upper ratio in shift
vratioLow = c(.3,.7)
vratioHigh = c(1.4,2)

#number of time series to simulate
n_series = 200


#### Load Data with IID Error Time Series with identifier ID and Time columns
d = get(load(fInp))
d_time = data.frame(Time = unique(d$Time))

#sample time series id
v_id = unique(d$ID)
v_id = sample(v_id, size = n_series)


##### Loop thru each series and simulate
d_x = data.frame()
M_ts = matrix(NA, nrow = nrow(d_time), ncol = n_series)

for( v in v_id ){
  pos = which(v_id==v) 
  print(pos)
  
  #lookup level and error
  dfv = subset(d, ID == v)
  l = dfv$level
  e = dfv$e 
  
  #randomly draw shift
  shiftIndex = sample(seq(vshiftRan[1],vshiftRan[2]), size=1)

  if( runif(1) < .5){ 
   shift = runif(1,vratioLow[1], vratioLow[2])
  } else{
  shift = runif(1,vratioHigh[1], vratioHigh[2])
 }
  
  #Apply shift
  x = ifelse( d_time$Time <= shiftIndex, l, l+log(shift)) +e
  
  #append
  ID_basis = paste(pos,"_shift")
  d_x = rbind(d_x, data.frame(Time = d_time$Time, ID =v,ID_basis, shiftIndex, shift, x)  )
  M_ts[,pos] = ts(x)
}


##### Save data to file
save(d_x, file = fOut)
