###### R code to produce sample paths for random walk with positive drift
# Created by Cole Sodja

##### Global Arguments
#directory to save data
dirOut = paste( getwd(), "/data/", sep='')

#rda file of dataframe containing errors e. #note that e is assumed to be on log-scale
fInp = paste( getwd(), "/data/d_local_level_seas.rda", sep='')

#full path to output dataframe to rda file
fOut = paste( getwd(), "/data/d_rwd.rda", sep='')

#directory to source functions
dirSrc = paste( getwd(), "/src/", sep='')

#slope range
vSlopeRan = c('lower' = .0001, 'upper'=.002)

#scale parameter range
vScaleRan = c('lower' = .2, 'upper'=.5)

#number of time series to simulate
n_series = 2000

##### Source Functions
l_list_func = list.files(dirSrc)

for( vfunc  in l_list_func){
  fpath = paste(dirSrc, vfunc, sep='')
  source(fpath)
}


#### Load Data with IID Error Time Series with identifier ID and Time columns
d_e = get(load(fInp))
d_time = data.frame(Time = unique(d_level$Time))
N = nrow(d_time)

#sample time series id
v_id = unique(d_e$ID)
v_id = sample(v_id, size = n_series)


##### Loop thru each series and simulate rwd
d_x = data.frame()
M_ts = matrix(NA, nrow = nrow(d_time), ncol = n_series)

for( v in v_id ){
  pos = which(v_id==v) 
  print(pos)
  
  #lookup error and compute sd
  e = as.numeric(subset(d_e, ID == v)$e )
  e_sd = sd(e)
  
  #randomly sample drift
  b = runif(1, vSlopeRan[1], vSlopeRan[2])
  
  #generate random walk with drift assuming Gaussian
  x = func.sim.rwd(N, e_sd, b)
  
  #rescale based on range of scale parm
  sScale = runif(1,vScaleRan[1],vScaleRan[2])
  x = ( x-min(x) )/(max(x) - min(x))
  x = .01 +sScale*x
  
  #append
  ID_basis = paste(pos,"_rwd")
  d_x = rbind(d_x, data.frame(Time = d_time$Time, ID =v,ID_basis, drift = b, x)  )
  M_ts[,pos] = ts(x)
}


##### Save data to file
save(d_x, file = fOut)

