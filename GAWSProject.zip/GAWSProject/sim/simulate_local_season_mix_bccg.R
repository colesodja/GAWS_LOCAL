###### R code to generate Local Seasonal+Pulse+RW+Shift Location Paths for BCCG process
# Created by Cole Sodja

###### Load libraries
require(gamlss)

##### Global Arguments
#directory to lookup and store data
dir_out = paste( getwd(), "/data/", sep='')

#maximum length of each time series
n_length = 24*21

##### Read Time Series Data, identified by ID, assuming level on log scale
#local level and seasonality bases
d_level = get( load( paste(dir_out, "/d_local_level_seas.rda" ,sep='')) )
v_id_s = as.character(unique(d_level$ID))

# random pulses, subset to where pulse >= 2
d_pulse = get( load( paste(dir_out, "/d_pulse.rda" ,sep='')) )
d_id2 = aggregate(data = d_pulse, pulse ~ ID, max)
prop_pulse = sum(d_id2$pulse>=2)/nrow(d_id2)
d_pulse = subset(d_pulse, ID %in% subset(d_id2, pulse >=1.5)$ID )
d_id1 = aggregate(data = d_level, level ~ ID, mean)
d_pulse = merge(d_pulse, d_id1, by = "ID")
d_pulse$x = log(d_pulse$pulse) + d_pulse$level
v_id_p = as.character(unique(d_pulse$ID))

#Random Walk Series
M_rw = get( load( paste(dir_out, "/Mat_rw.rda" ,sep='')) )

#Level Shift Series
M_shift = get( load( paste(dir_out, "/Mat_downward_shift.rda" ,sep='')) )

##### Generate 10 paths
M = matrix(NA, nrow = n_length, ncol = 20)

for(j in 1:10){
#randomly sample mixing weights
v_wt= runif(4)

if( any(v_wt <.1)  ){
v_wt[v_wt < .1] = .1+v_wt[v_wt < .1]
v_wt[which(v_wt==max(v_wt))] = v_wt[which(v_wt==max(v_wt))]-.1
}

v_wt = v_wt/sum(v_wt)

#randomly sample ID per series
v1 = sample(v_id_s,1)
v2 = sample(v_id_p,1)
v3 = sample(1:10,1)
v4 = sample(1:10,1)
  
#lookup time series
y1 = log(subset(d_level, ID==v1)$y.mu)
y2 = subset(d_pulse, ID==v2)$x
y3 = log(M_rw[,v3])
y4 = log(M_shift[,v4])

#randomly sample series
v_ts = sample(1:4,4, replace = FALSE)
Y = list('1'=y1, '2'=y2, '3'=y3, '4'=y4)
y = c()

for( v in v_ts){
z = Y[[v]] 
z = head(z, ceiling(v_wt[v]*n_length) )
y = c(y,z)
}

x = 1:n_length
z0 = mean(y)+(y1-mean(y1))
z0 = ifelse( x <= v_wt[1]*n_length,z0, 0)
z1 = mean(y)+(y2-mean(y2))
z2 = mean(y)+(y3-mean(y3))
y = head(y, n_length)
y = .6*y + .2*z0 + .15*z1 +.05*z2
y = exp(y)

#compute BCCG    
scl = sample( seq(.005, .05, .005), 1)
shp = sample( seq(-.05, .05, .01), 1)  
y = rBCCG(n_length, y, scl, shp)
M[,j] = y
}

#save 
mOut = paste( dir_out, "Mat_seas_mix.rda", sep="" )
save(M, file = mOut)
