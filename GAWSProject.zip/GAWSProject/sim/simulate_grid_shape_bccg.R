
###### R code to simulate constant time series from grid for BCCG shape parameter
# Created by Cole Sodja

##### Global Arguments
#directory to save data
dirOut = paste( getwd(), "/data/", sep='')

#full path to output dataframe to rda file
fOut = paste( getwd(), "/data/d_shape_constant.rda", sep='')

#range of BCCG shape parameter, assumed uniformly distributed
vGridRan = c(-.5,.5)

#number of time series to simulate
n_series = 2000

#length of time series
v_seq = seq(1,24*21 )

##### Samples of Values per Series
v_id = 1:n_series
v_p = runif(n_series, vGridRan[1], vGridRan[2])


##### Produce Constant Time Series 
d_s = data.frame(ID=v_id, shape = v_p)
d_time = data.frame(Time = v_seq)
d_s = merge(d_s,d_time)
d_s = d_s[order(d_s$ID, d_s$Time),]


##### Save data to file
d_s$BasisType = "constant_shape"
save(d_s, file = fOut)
