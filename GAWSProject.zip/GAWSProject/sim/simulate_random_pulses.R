###### R code to produce sample paths for iid random pulse models given level
# Created by Cole Sodja

##### Global Arguments
#directory to save data
dirOut = paste( getwd(), "/data/", sep='')

#rda file of dataframe containing local level. #note that level is assumed to be on log scale
fInp = paste( getwd(), "/data/d_local_level_seas.rda", sep='')

#full path to output dataframe to rda file
fOut = paste( getwd(), "/data/d_pulse.rda", sep='')

#integer range of pulses
v_n_pulse = 1:5

#number of time series to simulate
n_series = 100

#range of lift of pulse/shifts
v_shift_mu_ran = c(3,6)

#### Load Data with Level of Time Series with identifier ID and Time columns
d_level = get(load(fInp))
d_time = data.frame(Time = unique(d_level$Time))
v_seq = d_time$Time

#compute mean level for each time series identifer ID
d_id = aggregate(data = d_level, level ~ ID, mean)
d_id$level = exp(d_id$level)

#sample
v_id = d_id$ID
v_id = sample(v_id, size = n_series)
d_id = subset(d_id, ID %in% v_id)
d_id$ID_basis = paste( 1:nrow(d_id), "_pulse" )


##### Loop thru each series and generate random pulses
d_x = data.frame()

for( v in d_id$ID_basis ){
print(v)
  
#subset to time series
dy = subset(d_id, ID_basis == v)
dft = subset(d_level, ID==dy$ID)

#randomly draw number of pulses
n_pulse = sample(v_n_pulse, size=1)

# randomly assign pulse to time point
v_flag = sample(v_seq,size=n_pulse, replace = FALSE)

#generate lift per pulse
v_lift = runif( n_pulse, v_shift_mu_ran[1], v_shift_mu_ran[2])
x = rep(1,length(v_seq))
x[v_flag] <- v_lift

#generate random pulse series with level 
y0 = dft$y.mu
y = x*y0
  
#append time series
d_x  = rbind(d_x , data.frame(ID=dy$ID, ID_basis=dy$ID_basis, pulse = x, y.mu = y) )
}


##### Save data to file
save(d_x, file = fOut)

