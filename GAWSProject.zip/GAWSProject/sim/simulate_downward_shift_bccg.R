###### R code to generate Downward Shift Time Series Location for BCCG process
# Created by Cole Sodja

###### Load libraries
require(gamlss)

##### Global Arguments
#directory to lookup and store data
dir_out = paste( getwd(), "/data/", sep='')

#maximum length of each time series
n_length = 24*21

##### Read time series with step functions - subset to downward shift
d_shift = get( load( paste(dir_out, "/d_shift.rda" ,sep='')) )
d_id4 = aggregate(data = subset(d_shift, shift <= .7), shift ~ ID, min )
d_shift_down = subset(d_shift, ID %in% d_id4$ID )
rm(d_shift)

##### Generate 10 paths 
v_id_d = as.character(unique(d_shift_down$ID))
v_id_d = sample(v_id_d, 10)

M_shift = matrix(NA, nrow = n_length, ncol = 10)

for(j in 1:10){
  y = exp( subset( d_shift_down, ID==v_id_d[j])$x )
  scl = sample( seq(.01, .2, .01), 1)
  shp = sample( seq(-.1, .5, .01), 1)  
  y = rBCCG(n_length, y, scl, shp)
  M_shift[,j] = y
}

#save 
mOut = paste( dir_out, "Mat_downward_shift.rda", sep="" )
save(M_shift, file = mOut)
