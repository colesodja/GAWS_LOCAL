###### R code to generate Random Walk Time Series Location for BCCG process
# Created by Cole Sodja

###### Load libraries
require(gamlss)

##### Global Arguments
#directory to lookup and store data
dir_out = paste( getwd(), "/data/", sep='')

#maximum length of each time series
n_length = 24*21

##### Read Time Series Data, identified by ID, assuming level on log scale
#local level and seasonality bases
d_level = get( load( paste(dir_out, "/d_local_level_seas.rda" ,sep='')) )
v_level = sample(d_id1$level, 20)

##### Generate 20 location random walk for BCCG
M_rw = matrix(NA, nrow = n_length, ncol = 20)

for(j in 1:20){
  l.sd = sample( seq(.05, .2, .01), 1)
  l = arima.sim(list(order = c(0,1,0), sd = l.sd), n = n_length)
  l = 1+ ( l-min(l))/(max(l)-min(l))
  l = sample(v_level,1)+l
  y = exp(l)
  y = head(y, nrow(M_rw))
  scl = sample( seq(.1, .3, .01), 1)
  shp = sample( seq(-.1, .5, .01), 1)  
  y = rBCCG(n_length, y, scl, shp)
  M_rw[,j] = y
}

#save 
mOut = paste( dir_out, "Mat_rw.rda", sep="" )
save(M_rw, file = mOut)
