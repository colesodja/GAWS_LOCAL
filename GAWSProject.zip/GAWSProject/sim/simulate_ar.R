###### R code to produce sample paths for zero centered ar process
# Created by Cole Sodja

##### Load GAMLSS Library (assumed installed!)
require(gamlss)


##### Global Arguments
#directory to save data
dirOut = paste( getwd(), "/data/", sep='')

#rda file of dataframe containing errors e. #note that e is assumed to be on log-scale
fInp = paste( getwd(), "/data/d_local_level_seas.rda", sep='')

#full path to output dataframe to rda file
fOut = paste( getwd(), "/data/d_ar.rda", sep='')

#directory to source functions
dirSrc = paste( getwd(), "/src/", sep='')

#order of AR(P) with location and proportion parms from ZAP
loc_zap = .2
prop_zap = .8

#range of autocorrelation coefficients
ar_coef_ran = c('lower' = .05, 'upper' = .25)

#number of time series to simulate
n_series = 1000


##### Source Functions
l_list_func = list.files(dirSrc)

for( vfunc  in l_list_func){
  fpath = paste(dirSrc, vfunc, sep='')
  source(fpath)
}


#### Load Data with IID Error Time Series with identifier ID and Time columns
d_e = get(load(fInp))
d_time = data.frame(Time = unique(d_level$Time))
N = nrow(d_time)

#sample time series id
v_id = unique(d_e$ID)
v_id = sample(v_id, size = n_series)


##### Simulate from ZAP to store order
v_P = rZAP(n_series, loc_zap, prop_zap)

#Sample only Positive Order
v_P = v_P[v_P>0]
v_id = head(v_id, length(v_P) )

##### Loop thru each series and simulate zero-mean AR(p) processes
d_x = data.frame()
M_ts = matrix(NA, nrow = nrow(d_time), ncol = n_series)

for( v in v_id ){
pos = which(v_id==v) 
print(pos)

#lookup error and compute sd
e = as.numeric(subset(d_e, ID == v)$e )
e_sd = sd(e)

#lookup order
P = v_P[pos]

# sample coefficients if P>0 and call ar sim
if( P >0 ){
ar_coef = runif( P, min = as.numeric(ar_coef_ran[1]), max = as.numeric(ar_coef_ran[2])  )
e_0 = e[1:P]
x = func.sim.ar(N, e_0, e_sd, ar_coef)
} else{
x = e
}

#append
ID_basis = paste(pos,"_ar")
d_x = rbind(d_x, data.frame(Time = d_time$Time, ID =v,ID_basis, ar_order = P, x)  )
M_ts[,pos] = ts(x)
}


##### Save data to file
save(d_x, file = fOut)

