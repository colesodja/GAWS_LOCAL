
########## Detecting Anomalous Cloud Traffic Using GAWS
##Created by Cole Sodja

########## Global Arguments
#directory to read data
dirData = paste( getwd(), "/data/", sep='')

#directory to source functions
dirSrc = paste( getwd(), "/src/", sep='')

#directory to write results
dirResult = paste( getwd(), "/results/", sep='')

#rd file containing time series
fileTSData = paste( dirData, "/series_cloud_traffic.rda",sep='')

#output csv file containing ranking
fileOutRanks = paste( dirResult, "/ranks_gaws_cloud_traffic.csv",sep='')

#maximum number of time series to select to consider anomalies for f-score
maxRank = 10


#list of models to consider in computing Gamlss-Akaike-Weights anomaly scores
l_Family = list(
'parm' = list('minLik'= .001, 'nSample' = 50, 'minObsSubspace' = 15, 'nFourierBasis' =60, 'tsPeriod' = 2*24*7),
'l_bases' = 
list(
    "traffic_season_level_pulse" = 
      list(
        'locationName' = "season_level_pulse",
        'ScaleName' = "season",
        'ShapeName' = "level",
        'distributionFamily' = "TF",
        'basisFunction' = "func.gamlss.traffic.family.level.season",
        'likFunction' = "func.lik.traffic"
      ),
"traffic_spline_spline_constant" = 
  list(
    'locationName' = "spline",
    'ScaleName' = "spline",
    'ShapeName' = "constant",
    'distributionFamily' = "TF",
    'basisFunction' = "func.gamlss.traffic.location.spline.scale.spline",
    'likFunction' = "func.lik.traffic"
  )
 )
)

##### Source Functions
l_list_func = list.files(dirSrc)

for( vfunc  in l_list_func){
  fpath = paste(dirSrc, vfunc, sep='')
  source(fpath)
}

########### Read Data
d = get(load(fileTSData))


########### Prepare Time Series
#create matrix of series
M = d[,6:147]
ncol(M)
v_mu = apply(M,2,mean)
y_max = ceiling(max(v_mu)/10)*10
dfy = data.frame()

for(j in 1:ncol(M)){
  y = M[,j]
  y = y-mean(y) + y_max
  y = pmax(1,y)
  y = log(y)
  M[,j] = y
  d_y = data.frame(ID = j, Time = d$timeSeq, Dow = d$Dow, Hour = d$Hour, y)
  dfy = rbind(dfy, d_y)
}


########### GAWS Ranking: Slow Loops Can Take 15-40 Mins on laptop without pre-computing model space
d_rank_gaws = func.gaws.univariate.loop.use.par(dfy, l_Family, maxRank =ncol(M), printON = FALSE )


########### Save GAWS Ranking to CSV File
write.csv(d_rank_gaws, file = fileOutRanks, row.names  = FALSE)
