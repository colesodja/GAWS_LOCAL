
########## Detecting Anomalous Cloud Traffic using  stray
##Created by Cole Sodja

########## Global Arguments
#directory to read data
dirData = paste( getwd(), "/data/", sep='')

#directory to source functions
dirSrc = paste( getwd(), "/src/", sep='')

#directory to write results
dirResult = paste( getwd(), "/results/", sep='')

#rd file containing time series
fileTSData = paste( dirData, "/series_cloud_traffic.rda",sep='')

#output csv file containing ranking
fileOutRanks = paste( dirResult, "/ranks_stray_cloud_traffic.csv",sep='')

##### Source Functions
l_list_func = list.files(dirSrc)

for( vfunc  in l_list_func){
  fpath = paste(dirSrc, vfunc, sep='')
  source(fpath)
}


########### Read Data
d = get(load(fileTSData))

#create matrix of series
M = d[,6:147]
ncol(M)
v_mu = apply(M,2,mean)
y_max = ceiling(max(v_mu)/10)*10

for(j in 1:ncol(M)){
  y = M[,j]
  y = y-mean(y) + y_max
  y = pmax(1,y)
  y = log(y)
  M[,j] = y
}

########### Ranking
d_rank = func.stray.detection(M, numAlarm  = ncol(M) )

########### Save Ranking to CSV File
write.csv(d_rank, file = fileOutRanks, row.names  = FALSE)
