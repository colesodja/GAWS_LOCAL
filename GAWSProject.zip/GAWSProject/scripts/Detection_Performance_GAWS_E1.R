######### Experiment #1 - GAWS Detection Given:  Local level with multiple seasonality subspace
#Created by Cole Sodja

###KEY NOTE: LOCAL GAWS ALGORITHM FOR LOOPS VERY SLOW RUNNING ON LAPTOP!

########### Global Arguments
#Name of experiment for reporting
ExperimentName = "E1: Rank Anomaly|Seasonality"

#Number of "normal" subspaces
numSubspace = 1

#directory containing time series
dirSim = paste( getwd(), "/data/", sep='')

#directory to write results
dirResult = paste( getwd(), "/results/", sep='')

#file path to write csv containing rankings per anomaly
fileOutRank = paste( dirResult , "gaws_ranks_1.csv", sep="" )

#csv file to write containing results
fileOutPerf = paste( dirResult , "gaws_results_1.csv", sep="" )

#directory to source functions
dirSrc = paste( getwd(), "/src/", sep='')

#file wtih dataframe containing identifiers of time series, bases and anomalies
fileDataId =  paste( dirSim, "d_bases_id.rda", sep="" )

#file wtih matrix of time series
fileTS=  paste( dirSim, "Mat_series_sim.rda", sep="" )

#Number of "normal" time series to sample 
nSeries  = 200

#maximum number of time series to select to consider anomalies for f-score
maxRank = 10


#list of models to consider in computing Gamlss-Akaike-Weights anomaly scores
l_Family = list(
  'parm' = list( 'confLevelOutlier' = 0.0005, 'minLik'= 1/500, 'minObsSubspace' = 20),
  'l_bases' = 
    list(
      "spline_location_scale_shape" = 
        list(
          'locationName' = "spline",
          'ScaleName' = "spline",
          'ShapeName' = "spline",
          'distributionFamily' = c("BCCGo"),
          'basisFunction' = "func.gamlss.basis.spline",
          'likFunction' = "func.lik.iid",
          'arg' = list('shapes' = c('sigma','shape'), 'mRows'  = 1 ),
          'reconstruct' = FALSE
        ),
      "constant_location_scale" = 
        list(
          'locationName' = "constant",
          'ScaleName' = "constant",
          'ShapeName' = NULL,
          'distributionFamily' = c("GA"),
          'basisFunction' = "func.gamlss.basis.constant",
          'likFunction' = "func.lik.iid",
          'arg' = list('nIndex'=24*7, 'shapes' = c('sigma'), 'mRows'  = 1 ),
          'reconstruct' = FALSE
        ),
      "constant_location_scale_shape" = 
        list(
          'locationName' = "constant",
          'ScaleName' = "constant",
          'ShapeName' = "constant",
          'distributionFamily' = c("BCCGo"),
          'basisFunction' = "func.gamlss.basis.constant",
          'likFunction' = "func.lik.iid",
          'arg' = list('nIndex'=24*7, 'shapes' = c('sigma','nu'), 'mRows'  = 1 ),
          'reconstruct' = FALSE
        ),
      "level_seas_constant_scale" = 
        list(
          'locationName' = "gamlss_level_seas_",
          'ScaleName' = "constant",
          'ShapeName' = NULL,
          'distributionFamily' = c("GA"),
          'basisFunction' = "func.gamlss.basis.level.seas",
          'likFunction' = "func.lik.seas",
          'arg' = list('nIndex'=24*7*2, 'shapes' = c('sigma'), 'mRows'  = 24*21),
          'reconstruct' = FALSE
        ),
      "level_seas_constant_scale_shape" = 
        list(
          'locationName' = "gamlss_level_seas_",
          'ScaleName' = "constant",
          'ShapeName' = "constant",
          'distributionFamily' = c("BCCGo"),
          'basisFunction' = "func.gamlss.basis.level.seas",
          'likFunction' = "func.lik.seas",
          'arg' = list('nIndex'=24*7*2,'shapes' = c('sigma','nu'), 'mRows'  = 24*21),
          'reconstruct' = FALSE
        ),
      "level_pulse_constant_scale" = 
        list(
          'locationName' = "gamlss_level_pulse_",
          'ScaleName' = "constant",
          'ShapeName' = NULL,
          'distributionFamily' = c("GA"),
          'basisFunction' = "func.gamlss.basis.level.pulse",
          'likFunction' = "func.lik.pulse",
          'arg' = list('nIndex'=24*21,'shapes' = c('sigma'), 'mRows'  = 24*21),
          'reconstruct' = TRUE
        ),
      "level_pulse_constant_scale_shape" = 
        list(
          'locationName' = "gamlss_level_pulse_",
          'ScaleName' = "constant",
          'ShapeName' = "constant",
          'distributionFamily' = c("BCCGo"),
          'basisFunction' = "func.gamlss.basis.level.pulse",
          'likFunction' = "func.lik.pulse",
          'arg' = list('nIndex'=24*21,'shapes' = c('sigma','nu'), 'mRows'  = 24*21),
          'reconstruct' = TRUE
        ),
      "step_positive_constant_scale" = 
        list(
          'locationName' = "gamlss_step_positive_",
          'ScaleName' = "constant",
          'ShapeName' = "constant",
          'distributionFamily' = c("GA"),
          'basisFunction' = "func.gamlss.basis.step.positive",
          'likFunction' = "func.lik.step",
          'arg' = list('nIndex'=24*21,'shapes' = c('sigma'), 'mRows'  = 24*21),
          'reconstruct' = TRUE
        ),
      "step_positive_constant_scale_shape" = 
        list(
          'locationName' = "gamlss_step_positive_",
          'ScaleName' = "constant",
          'ShapeName' = "constant",
          'distributionFamily' = c("BCCGo"),
          'basisFunction' = "func.gamlss.basis.step.positive",
          'arg' = list('nIndex'=24*21,'shapes' = c('sigma','nu'),'mRows'= 24*21),
          'likFunction' = "func.lik.step",
          'reconstruct' = TRUE
        ),
      "ar_constant_scale" = 
        list(
          'locationName' = "gamlss_ar_",
          'ScaleName' = "constant",
          'ShapeName' = NULL,
          'distributionFamily' = c("GA"),
          'basisFunction' = "func.gamlss.basis.ar",
          'arg' = list('nIndex'=24*7,'shapes' = c('sigma'),'mRows'= 24*21),
          'likFunction' = "func.lik.ar",
          'reconstruct' = TRUE
        ),
      "ar_constant_scale_shape" = 
        list(
          'locationName' = "gamlss_ar_",
          'ScaleName' = "constant",
          'ShapeName' = NULL,
          'distributionFamily' = c("BCCGo"),
          'basisFunction' = "func.gamlss.basis.ar",
          'likFunction' = "func.lik.ar",
          'arg' = list('nIndex'=24*7,'shapes' = c('sigma','nu'), 'mRows' = 24*21),
          'reconstruct' = TRUE
        )
    )
)   

##### Source Functions
l_list_func = list.files(dirSrc)

for( vfunc  in l_list_func){
  fpath = paste(dirSrc, vfunc, sep='')
  source(fpath)
}


########### Read Data
#actual bases identifier
d_subspace_id = get(load(fileDataId ))

#matrix of time series over common index
M_series = get(load(fileTS ))

#lookup time vector, based on 24*21 hourly data for month of Jan 
v_time = seq( as.POSIXct("2019-01-01 00"), as.POSIXct("2019-01-31 23"), by=3600)
v_time = head(v_time, nrow(M_series))

#lookup id associated with anomalies
v_id_anomaly = subset(d_subspace_id, BasisID=="B_anomaly")$tsID



########### Normalize Time Series
for(j in 1:ncol(M_series)){
  z = log(M_series[,j]+1) 
  z = (z-mean(z))/( max(z) - min(z))
  z = z + log(500)
  M_series[,j] = exp(z) 
}


######### Matrix of Normal Series to sample 
d_s = subset(d_subspace_id, Subspace == "Mat_level_seas")
M_norm = M_series[, d_s$tsID]


######### Matrix of Anomalies
M_anomaly = M_series[, v_id_anomaly]


######## Main Function to Rank Anomalous Series
func.rank = function(  M_norm, M_anomaly, v_eval, nSeries, numAnomaly  ){
#list to store ranking and results 
l_p = list()

#create matrix with normal and anomalous series
vPosA = which( v_eval == v_id_anomaly)
N = nSeries - numAnomaly
v_id_normal = 1:ncol(M_norm)
v_id_normal= sample(v_id_normal, N)
M = M_norm[, v_id_normal]   
M = cbind(M, M_anomaly[,vPosA] )  
v_anomaly_index = seq(N+1, nSeries)

#subspace mapping
d_sp = data.frame( ID = c(v_id_normal, v_eval))
d_sp$Col = 1:ncol(M)

#create dataframe with time series
 dfy = data.frame()
  
  for( j in 1:ncol(M) ){
    dfy = rbind(dfy,data.frame( ID=j, Time = v_time, Index = 1:nrow(M),y = M[,j]))
  }

##rank anomalies - Slow Loop per Series/Model Families Running Local Expect > 10 Minutes
d_rank = func.gaws.univariate.loop(dfy, l_Family, maxRank =ncol(M) )
d_rank = d_rank[,c("Rank","Col")]
d_rank$Method = "gaws"
d_rank = merge(d_rank, d_sp, by = "Col")

#detection performance
d_rank$isAnomaly = ifelse( d_rank$Col %in% v_anomaly_index, 1,0  )
d_fscore = func.fscore(d_rank, maxRank)
d_er =   func.excess.rank( d_rank, N = ncol(M), numAnomaly)
d_result = merge(d_fscore, d_er, by = "Method")
d_result$numAnomaly = numAnomaly
d_result$AnomalyID = paste(v_eval, collapse = "|")

#save 
l_p = list('rank' = d_rank, 'result' = d_result)
return(l_p)
}  


### Wrapper to loop
func.Main = function(M_norm, M_anomaly, v_eval,  nSeries, numAnomaly, nLoop = 1, ExperimentName){
#dataframe to save results
d_rk = data.frame()
d_p = data.frame()

## loop and re-compute ranking/result
for( i in 1:nLoop){
  print(i)
  l_p = func.rank( M_norm, M_anomaly, v_eval, nSeries, numAnomaly )
  d_rk = rbind(d_rk, l_p$rank)
  d_p = rbind(d_p, l_p$result)
}

#output 
l_e = list('rank' = d_rk, 'result' = d_p)
return(l_e)
}

### compute ranking performance 
func.Main.Perf = function(M_norm, M_anomaly, v_aID, nSeries, numAnomaly, nLoop = 1, ExperimentName ){
#dataframe to append results
d_a = data.frame()
d_rk = data.frame()
  
#starting position of anomaly
previousAID  = min(v_id_anomaly)   

##loop 
for( v in v_aID ){
  v_pos = seq( which(previousAID==v_id_anomaly),which(v==v_id_anomaly))
  v_eval = v_id_anomaly[v_pos]  
  print( paste("Anomaly IDs:", paste(v_eval,collapse = ";") ) )  
  previousAID = v+1
  
  #Rank   
  l_p = func.Main(M_norm, M_anomaly, v_eval,  nSeries, numAnomaly, nLoop, ExperimentName)
  d_p = l_p$result
  d_r = l_p$rank
  
  #Append
  d_rk = rbind(d_rk, d_r)
  d_a = rbind(d_a, d_p)
}

# Compute Average Performance
d_p = d_a
d_p$N = nSeries - numAnomaly
d_p$ExperimentName = ExperimentName
d_p$numAnomaly = numAnomaly
d_p$numSubspace = numSubspace
d_perf = sqldf('Select  Method, ExperimentName, numSubspace, numAnomaly, avg(fScore) as fScore, avg(excess_rank) as excess_rank, avg(excess_rank_abs) as excess_rank_abs from d_p group by 1,2,3,4')

# Compute Minimum Ranking for Anomalies
d_ar = subset( d_rk, isAnomaly ==1)
d_ar = sqldf('Select ID, min(Rank) as minRank from d_ar group by 1')
d_ar$ExperimentName = ExperimentName
d_ar$numSubspace = numSubspace
d_ar$numAnomaly = numAnomaly

#output list 
l_o = list('perf' = d_perf, 'rank' = d_ar)
}


######### Setup Experiments
d_perf_all = data.frame()
d_perf_anomaly = data.frame()


######### Evaluation: 1 anomaly per run
v_aID = seq(v_id_anomaly[1], v_id_anomaly[10], by=1)
l_1 = func.Main.Perf(M_norm, M_anomaly, v_aID, nSeries, numAnomaly = 1, nLoop = 1, ExperimentName)
d_perf_all =  rbind(d_perf_all, l_1$perf)
d_perf_anomaly =  rbind(d_perf_anomaly, l_1$rank)


######### Evaluation: 5 anomaly per run
v_aID = seq(v_id_anomaly[5], v_id_anomaly[10], by=5)
l_2 = func.Main.Perf(M_norm, M_anomaly,v_aID,nSeries,numAnomaly =5,nLoop = 1, ExperimentName)
d_perf_all =  rbind(d_perf_all, l_2$perf)
d_perf_anomaly =  rbind(d_perf_anomaly, l_2$rank)


######### Evaluation: 10 anomaly per run
v_aID = v_id_anomaly[10]
l_3 = func.Main.Perf(M_norm, M_anomaly, v_aID, nSeries,numAnomaly =10, nLoop = 1, ExperimentName)
d_perf_all =  rbind(d_perf_all, l_3$perf)
d_perf_anomaly =  rbind(d_perf_anomaly, l_3$rank)


######### Save Data
write.csv( d_perf_all, row.names = FALSE, file = fileOutPerf )
write.csv( d_perf_anomaly, row.names = FALSE, file = fileOutRank )
