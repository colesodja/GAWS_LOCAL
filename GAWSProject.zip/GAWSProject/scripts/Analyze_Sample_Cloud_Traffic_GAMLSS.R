
########## Analysis of Cloud Traffic Series and GAMLSS Specifications
##Created by Cole Sodja

########## Load Packages
require(gamlss)
require(sqldf)
require(forecast)
require(splines)

########## Global Arguments
#directory containing time series
dirData = paste( getwd(), "/data/", sep='')

#file containing some sample traffic time series
fileTSData = paste( dirData, "/sample_series_cloud_traffic.rda",sep='')

#directory to source functions
dirSrc = paste( getwd(), "/src/", sep='')

##########  Source Functions
l_list_func = list.files(dirSrc)

for( vfunc  in l_list_func){
  fpath = paste(dirSrc, vfunc, sep='')
  source(fpath)
}


########### Read Time Series
d_sample  = get(load(fileTSData))
nrow(d_sample)

# plot
plot(data = d_sample, z ~ x)
plot(data = d_sample, z ~ S_peak)
plot( data= d_sample, z ~ l)
plot( data= d_sample, z ~ yhat)
plot( data= d_sample, z ~ z_lag)
plot( data= d_sample, z ~ Hour)
plot( data= d_sample, z ~ Dow)


############# Fit model
fit1 =  gamlss(data = d_sample, 
               z ~ z_lag, 
               sigma.formula = ~ pb(S_peak),
               nu.formula = ~ 1,
               family = "TF" 
)

wp(fit1)
AIC(fit1)


fitz =  gamlss(data = d_sample, 
               z ~ z_lag, 
               sigma.formula = ~ pb(S_peak, degree=1, df=2),
               nu.formula = ~ pb(l, degree=2, df=3),
               family = "TF" 
)


BIC(fit1, fitz)


############# Visualize Plots
#worm plot
wp(fitz, ylim.all=.6) 

#relative prediction per basis
term.plot(fitz, what='sigma', ylab='Scale', xlab = 'Rel Season Peak')
term.plot(fitz, what='nu',ylab='Shape', xlab = 'Level')



