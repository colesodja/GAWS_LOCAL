
########## Applying GAWS Algorithm for Detecting Shape Anomaly Consisting of level Shift versus none
##Created by Cole Sodja

########## Global Arguments
#directory to source functions
dirSrc = paste( getwd(), "/src/", sep='')

#directory to read data
dirData = paste( getwd(), "/data/", sep='')

#rda file of dataframe with normalized series 
fileTS = paste( dirData, "/ped_series.rda",sep='')

#directory to write results
dirResult = paste( getwd(), "/results/", sep='')

#name of csv file to output GAWS scores 
fileOutRanks  = paste( dirResult, "/gaws_ranking_ped_series.csv",sep='')

#list of models to consider in computing Gamlss-Akaike-Weights anomaly scores
l_Family = list(
'parm' = list('minLik'= .001),
'l_bases' = 
list(
    "normal" = 
      list(
        'basisFunction' = "func.gamlss.tf.hour.dow",
		'isNormal' = 'Y'
      ),
	      "alternative" = 
      list(
        'basisFunction' = "func.gamlss.tf.hour.dow.shift",
		'isNormal' = 'N'
      )
	)
)


##### Source Functions
l_list_func = list.files(dirSrc)

for( vfunc  in l_list_func){
  fpath = paste(dirSrc, vfunc, sep='')
  source(fpath)
}



########### Read Data
d = get(load(fileTS))


##loop thru each series and add to dataframe 
dfy = data.frame()
v_id = 1:39

for( j in v_id ){
dfj = data.frame(ID = j, Time = d$Time, Hour  = d$Hour, Dow = d$Dow, Seq= 1:nrow(d))
dfj$y = log(d[, j+4]+1)
dfy = rbind(dfy, dfj)
}

########### GAWS Ranking
d_rank_gaws = func.gaws.pass1(dfy, l_Family, maxRank =ncol(M), printON = FALSE)

########### Highlight Top 6 Series in Red 
M = as.matrix( d[,5:ncol(d)])
v_id = 1:ncol(M)
v_col = ifelse(  v_id %in% subset(d_rank_gaws, Rank <=6)$Col, "red", "grey")

ts.plot(M[,!v_col=="red"], col = 'grey', main='Series > GAWS Rank 6')

plot(ts(M[,v_col=="red"]), col = 'red', main='Series <= GAWS Rank 6')

########### Save GAWS Ranking to CSV File
write.csv(d_rank_gaws, file = fileOutRanks, row.names  = FALSE)
