######### Experiment 2 Measure Stray performance: Seasonality, Pulse, Upward Step, Autoregressive subspaces
#Created by Cole Sodja

########### Load Libraries
require(oddstream)
require(stray)
require(sqldf)

########### Global Arguments
#Name of experiment for reporting
ExperimentName = "E2: Rank Anomaly|Seasonality, Pulses, AR, Shift"

#Number of "normal" subspaces
numSubspace = 4

#directory containing time series
dirSim = paste( getwd(), "/data/", sep='')

#directory to write results
dirResult = paste( getwd(), "/results/", sep='')

#file path to write csv containing rankings per anomaly
fileOutRank = paste( dirResult , "stray_ranks_2.csv", sep="" )

#csv file to write containing results
fileOutPerf = paste( dirResult , "stray_results_2.csv", sep="" )

#directory to source functions
dirSrc = paste( getwd(), "/src/", sep='')

#file wtih dataframe containing identifiers of time series, bases and anomalies
fileDataId =  paste( dirSim, "d_bases_id.rda", sep="" )

#file wtih matrix of time series
fileTS=  paste( dirSim, "Mat_series_sim.rda", sep="" )

#Number of "normal" time series to sample 
nSeries  = 200

#maximum number of time series to select to consider anomalies for f-score
maxRank = 10

##### Source Functions
l_list_func = list.files(dirSrc)

for( vfunc  in l_list_func){
  fpath = paste(dirSrc, vfunc, sep='')
  source(fpath)
}


########### Read Data
#actual bases identifier
d_subspace_id = get(load(fileDataId ))

#matrix of time series over common index
M_series = get(load(fileTS ))

#lookup time vector, based on 24*21 hourly data for month of Jan 
v_time = seq( as.POSIXct("2019-01-01 00"), as.POSIXct("2019-01-31 23"), by=3600)
v_time = head(v_time, nrow(M_series))

#lookup id associated with anomalies
v_id_anomaly = subset(d_subspace_id, BasisID=="B_anomaly")$tsID



########### Normalize Time Series
for(j in 1:ncol(M_series)){
  z = log(M_series[,j]+1) 
  z = (z-mean(z))/( max(z) - min(z))
  z = z + log(500)
  M_series[,j] = exp(z) 
}


######### Matrix of Normal Series to sample 
d_s = subset(d_subspace_id, Subspace %in% c( "Mat_level_seas", "Mat_pulse", "Mat_shift_up", "Mat_ar" ) )
M_norm = M_series[, d_s$tsID]


######### Matrix of Anomalies
M_anomaly = M_series[, v_id_anomaly]



######## Main Function to Rank Anomalous Series
func.rankHDR = function(  M_norm, M_anomaly, v_eval, nSeries, numAnomaly  ){
#list to store ranking and results 
l_p = list()

## create matrix with normal and anomalous series
N = nSeries - numAnomaly
v_id_normal = 1:ncol(M_norm)

#Sample 10 shift up
v1 = which(d_s$Subspace %in% "Mat_shift_up")
M1 = M_norm[,v1]

#Randomly Sample 2 subspace with proportion between .1 and .6
v_prob = runif(2,.1,.6)

#Assign Pulse
K = N-10
v2 = which(d_s$Subspace %in% "Mat_pulse")
v2 = sample(v2, v_prob[1]*K)
M2 = M_norm[, v2]

#Assign AR
K = K-length(v2)
v3 = which(d_s$Subspace %in% "Mat_ar")
v3 = sample(v3, v_prob[1]*K)
M3 = M_norm[, v3]

#Assign remainder to level_seas
K = K-length(v3)
v4 = which(d_s$Subspace %in% "Mat_level_seas")
v4 = sample(v4, K)
M4 = M_norm[, v4]

#join normal series
v_id_normal = c(v1,v2,v3,v4) 
M = M_norm[, v_id_normal]  

#join anomalous series
vPosA = which( v_eval == v_id_anomaly)
M = cbind(M, M_anomaly[,vPosA] )  
v_anomaly_index = seq(N+1, nSeries)

#subspace mapping
d_sp = data.frame( ID = c(v_id_normal, v_eval))
d_sp$Col = 1:ncol(M)

##rank anomalies based on anomalous package
d_rank_hdr = pd.stray(Y1 = M, numAlarm = ncol(M))
d_rank_hdr = d_rank_hdr[,c("Rank","Col")]
d_rank_hdr$Method = "stray"
d_rank_hdr = merge(d_rank_hdr, d_sp, by = "Col")

#detection performance
d_rank_hdr$isAnomaly = ifelse( d_rank_hdr$Col %in% v_anomaly_index, 1,0  )
d_fscore = func.fscore(d_rank_hdr, maxRank)
d_er =   func.excess.rank( d_rank_hdr, N = ncol(M), numAnomaly)
d_result = merge(d_fscore, d_er, by = "Method")
d_result$numAnomaly = numAnomaly
d_result$AnomalyID = paste(v_eval, collapse = "|")

#save 
l_p = list('rank' = d_rank_hdr, 'result' = d_result)
return(l_p)
}  


### Wrapper to loop
func.Main = function(M_norm, M_anomaly, v_eval,  nSeries, numAnomaly, nLoop = 10, ExperimentName){
#dataframe to save results
d_rk = data.frame()
d_p = data.frame()

## loop and re-compute ranking/result
for( i in 1:nLoop){
  print(i)
  l_p = func.rankHDR( M_norm, M_anomaly, v_eval, nSeries, numAnomaly )
  d_rk = rbind(d_rk, l_p$rank)
  d_p = rbind(d_p, l_p$result)
}

#output 
l_e = list('rank' = d_rk, 'result' = d_p)
return(l_e)
}




### compute ranking performance 
func.Main.Perf = function(M_norm, M_anomaly, v_aID, nSeries, numAnomaly, nLoop = 10, ExperimentName ){
#dataframe to append results
d_a = data.frame()
d_rk = data.frame()
  
#starting position of anomaly
previousAID  = min(v_id_anomaly)   

##loop 
for( v in v_aID ){
  v_pos = seq( which(previousAID==v_id_anomaly),which(v==v_id_anomaly))
  v_eval = v_id_anomaly[v_pos]  
  print( paste("Anomaly IDs:", paste(v_eval,collapse = ";") ) )  
  previousAID = v+1
  
  #Rank   
  l_p = func.Main(M_norm, M_anomaly, v_eval,  nSeries, numAnomaly, nLoop, ExperimentName)
  d_p = l_p$result
  d_r = l_p$rank
  
  #Append
  d_rk = rbind(d_rk, d_r)
  d_a = rbind(d_a, d_p)
}

# Compute Average Performance
d_p = d_a
d_p$N = nSeries - numAnomaly
d_p$ExperimentName = ExperimentName
d_p$numAnomaly = numAnomaly
d_p$numSubspace = numSubspace
d_p$fScore = ifelse( is.na(d_p$fScore),0,d_p$fScore)
d_perf = sqldf('Select  Method, ExperimentName, numSubspace, numAnomaly, avg(fScore) as fScore, avg(excess_rank) as excess_rank, avg(excess_rank_abs) as excess_rank_abs from d_p group by 1,2,3,4')

# Compute Minimum Ranking for Anomalies
d_ar = subset( d_rk, isAnomaly ==1)
d_ar = sqldf('Select ID, min(Rank) as minRank from d_ar group by 1')
d_ar$ExperimentName = ExperimentName
d_ar$numSubspace = numSubspace
d_ar$numAnomaly = numAnomaly

#output list 
l_o = list('perf' = d_perf, 'rank' = d_ar)
}


######### Setup Experiments
d_perf_all = data.frame()
d_perf_anomaly = data.frame()



######### Evaluation: 1 anomaly per run
v_aID = seq(v_id_anomaly[1], v_id_anomaly[10], by=1)
l_1 = func.Main.Perf(M_norm, M_anomaly, v_aID, nSeries, numAnomaly = 1, nLoop = 10, ExperimentName)
d_perf_all =  rbind(d_perf_all, l_1$perf)
d_perf_anomaly =  rbind(d_perf_anomaly, l_1$rank)


######### Evaluation: 5 anomaly per run
v_aID = seq(v_id_anomaly[5], v_id_anomaly[10], by=5)
l_2 = func.Main.Perf(M_norm, M_anomaly,v_aID,nSeries,numAnomaly =5,nLoop = 20, ExperimentName)
d_perf_all =  rbind(d_perf_all, l_2$perf)
d_perf_anomaly =  rbind(d_perf_anomaly, l_2$rank)


######### Evaluation: 10 anomaly per run
v_aID = v_id_anomaly[10]
l_3 = func.Main.Perf(M_norm, M_anomaly, v_aID, nSeries,numAnomaly = 10, nLoop = 30, ExperimentName)
d_perf_all =  rbind(d_perf_all, l_3$perf)
d_perf_anomaly =  rbind(d_perf_anomaly, l_3$rank)


######### Save Data
write.csv( d_perf_all, row.names = FALSE, file = fileOutPerf )
write.csv( d_perf_anomaly, row.names = FALSE, file = fileOutRank )
