######### Experiment Measure Stray performance - Constant Normal Basis, 20 anomalies
#Created by Cole Sodja

########### Load Libraries
require(sqldf)
require(gamlss)
require(oddstream)
require(stray)
require(anomalous)


########### Global Arguments
#Name of experiment for reporting
ExperimentName = "E3: Rank Anomaly|Constant and 10 distinct/10 similar temp-shift anomalies"

#Number of "normal" subspaces
numSubspace = 1

#directory containing time series
dirSim = paste( getwd(), "/data/", sep='')

#directory to write results
dirResult = paste( getwd(), "/results/", sep='')

#file path to write csv containing rankings per anomaly
fileOutRank = paste( dirResult , "hdr_ranks_3.csv", sep="" )

#csv file to write containing results
fileOutPerf = paste( dirResult , "hdr_results_3.csv", sep="" )

#directory to source functions
dirSrc = paste( getwd(), "/src/", sep='')

#file wtih dataframe containing identifiers of time series, bases and anomalies
fileDataId =  paste( dirSim, "d_bases_id.rda", sep="" )

#file wtih matrix of time series
fileTS=  paste( dirSim, "Mat_series_sim.rda", sep="" )

#Number of "normal" time series to sample 
nSeries  = 200

#maximum number of time series to select to consider anomalies for f-score
maxRank = 20

##### Source Functions
l_list_func = list.files(dirSrc)

for( vfunc  in l_list_func){
  fpath = paste(dirSrc, vfunc, sep='')
  source(fpath)
}


########### Read Data
#actual bases identifier
d_subspace_id = get(load(fileDataId ))

#matrix of time series over common index
M_series = get(load(fileTS ))

#lookup time vector, based on 24*21 hourly data for month of Jan 
v_time = seq( as.POSIXct("2019-01-01 00"), as.POSIXct("2019-01-31 23"), by=3600)
v_time = head(v_time, nrow(M_series))

#lookup id associated with anomalies
v_id_anomaly = subset(d_subspace_id, BasisID=="B_anomaly")$tsID



########### Normalize Time Series
for(j in 1:ncol(M_series)){
  z = log(M_series[,j]+1) 
  z = (z-mean(z))/( max(z) - min(z))
  z = z + log(500)
  M_series[,j] = exp(z) 
}


########### Select Normal Time Series
#constant location, scale, shape bases from bccg
M_norm = matrix(NA, nrow = length(v_time), ncol = nSeries - 20)

for(j in 1:ncol(M_norm) ){
  Sig = runif(1,.1,.2)
  Nu = rnorm(1,-.1,.02)
  M_norm[, j] = rBCCG( length(v_time), 500, Sig, Nu )
}



######### Matrix of "Distinct" 10 Anomalies
M_anom1 = M_series[, v_id_anomaly]


######### Matrix of "Same" 10 Anomalies - Temporary Step Functions
M_anom2 = matrix( NA, nrow = length(v_time), ncol = 10)
v_CP1 = sample( 200:250,1)
v_N = sample( 75:125,1)
x = 1:length(v_time)

for(j in 1:10){
  #simulate random step-up ratio 
  vLift = runif(1,1.25,1.5)
  
  #Create Temp Shift 
  vShift = ifelse(x < v_CP1, 1, ifelse( x >= v_CP1 & x <= v_CP1+ v_N, vLift, 1) )
  
  #simulate 
  l = rnorm( 1, 500,12)
  y_mu = l*vShift
  y_mu = l+y_mu-mean(y_mu)
  Sig = runif(1,.01,.05)
  Nu =  runif(1,-.5,-.2)
  Sig = ifelse( x >= v_CP1 & x <= v_CP1+ v_N, Sig*.2, Sig)
  Nu = ifelse( x >= v_CP1 & x <= v_CP1+ v_N, .25, Nu)
  y = rBCCGo( length(y_mu), y_mu, Sig, Nu)
  M_anom2 [,j] = y
}


M_anomaly = cbind(M_anom1, M_anom2)
v_id_anomaly = 1:ncol(M_anomaly) + ncol(M_norm)



######## Main Function to Rank Anomalous Series 
func.rankHDR = function(  M_norm, M_anomaly, v_eval, nSeries, numAnomaly  ){
#list to store ranking and results 
l_p = list()

## create matrix with normal and anomalous series
N = nSeries - numAnomaly
v_id_normal = 1:ncol(M_norm)
v_id_normal= sample(v_id_normal, N)
M = M_norm[, v_id_normal]  

#join anomalous series
vPosA = which( v_eval == v_id_anomaly)
M = cbind(M, M_anomaly[,vPosA] )  
v_anomaly_index = seq(N+1, nSeries)

#subspace mapping
d_sp = data.frame( ID = c(v_id_normal, v_eval))
d_sp$Col = 1:ncol(M)

##rank anomalies 
d_rank_hdr = pd.anomalous.hyndman(Y1 = M, numAlarm = ncol(M))
d_rank_hdr = d_rank_hdr[,c("Rank","Col")]
d_rank_hdr$Method = "pca+hdr"
d_rank_hdr = merge(d_rank_hdr, d_sp, by = "Col")

#detection performance
d_rank_hdr$isAnomaly = ifelse( d_rank_hdr$Col %in% v_anomaly_index, 1,0  )
d_fscore = func.fscore(d_rank_hdr, maxRank)
d_er =   func.excess.rank( d_rank_hdr, N = ncol(M), numAnomaly)
d_result = merge(d_fscore, d_er, by = "Method")
d_result$numAnomaly = numAnomaly
d_result$AnomalyID = paste(v_eval, collapse = "|")

#save 
l_p = list('rank' = d_rank_hdr, 'result' = d_result)
return(l_p)
}  


### Wrapper to loop
func.Main = function(M_norm, M_anomaly, v_eval,  nSeries, numAnomaly, nLoop = 10, ExperimentName){
#dataframe to save results
d_rk = data.frame()
d_p = data.frame()

## loop and re-compute ranking/result
for( i in 1:nLoop){
  print(i)
  l_p = func.rankHDR( M_norm, M_anomaly, v_eval, nSeries, numAnomaly )
  d_rk = rbind(d_rk, l_p$rank)
  d_p = rbind(d_p, l_p$result)
}

#output 
l_e = list('rank' = d_rk, 'result' = d_p)
return(l_e)
}




### compute ranking performance 
func.Main.Perf = function(M_norm, M_anomaly, v_aID, nSeries, numAnomaly, nLoop = 10, ExperimentName ){
#dataframe to append results
d_a = data.frame()
d_rk = data.frame()
  
#starting position of anomaly
previousAID  = min(v_id_anomaly)   

##loop 
for( v in v_aID ){
  v_pos = seq( which(previousAID==v_id_anomaly),which(v==v_id_anomaly))
  v_eval = v_id_anomaly[v_pos]  
  print( paste("Anomaly IDs:", paste(v_eval,collapse = ";") ) )  
  previousAID = v+1
  
  #Rank   
  l_p = func.Main(M_norm, M_anomaly, v_eval,  nSeries, numAnomaly, nLoop, ExperimentName)
  d_p = l_p$result
  d_r = l_p$rank
  
  #Append
  d_rk = rbind(d_rk, d_r)
  d_a = rbind(d_a, d_p)
}

# Compute Average Performance
d_p = d_a
d_p$N = nSeries - numAnomaly
d_p$ExperimentName = ExperimentName
d_p$numAnomaly = numAnomaly
d_p$numSubspace = numSubspace
d_p$fScore = ifelse( is.na(d_p$fScore),0,d_p$fScore)
d_perf = sqldf('Select  Method, ExperimentName, numSubspace, numAnomaly, avg(fScore) as fScore, avg(excess_rank) as excess_rank, avg(excess_rank_abs) as excess_rank_abs from d_p group by 1,2,3,4')

# Compute Minimum Ranking for Anomalies
d_ar = subset( d_rk, isAnomaly ==1)
d_ar = sqldf('Select ID, min(Rank) as minRank from d_ar group by 1')
d_ar$ExperimentName = ExperimentName
d_ar$numSubspace = numSubspace
d_ar$numAnomaly = numAnomaly

#output list 
l_o = list('perf' = d_perf, 'rank' = d_ar)
}


######### Setup Experiments
d_perf_all = data.frame()
d_perf_anomaly = data.frame()


######### Evaluation: 20 anomaly per run
v_aID = v_id_anomaly[20]
l_1 = func.Main.Perf(M_norm, M_anomaly, v_aID, nSeries, numAnomaly = 20, nLoop = 10, ExperimentName)
d_perf_all =  rbind(d_perf_all, l_1$perf)
d_perf_anomaly =  rbind(d_perf_anomaly, l_1$rank)


######### Save Data
write.csv( d_perf_all, row.names = FALSE, file = fileOutPerf )
write.csv( d_perf_anomaly, row.names = FALSE, file = fileOutRank )
