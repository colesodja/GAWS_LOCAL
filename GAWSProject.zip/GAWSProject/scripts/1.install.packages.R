############# Installs Necessary Packages
###Created by Cole Sodja

func.check.install.pkg <- function(pkgName){
#check if package installed
func.check <- function(pkgName){
chk <- tryCatch( require(pkgName, character.only = TRUE), error = function(e) FALSE)
return(chk)
}

chk <- suppressWarnings(func.check(pkgName))

if( chk == FALSE){
#attempt to install package 
print( paste("Attempting to install package: ", pkgName, sep=""))
install.packages(pkgName)
}
}


func.check.install.pkg('forecast')
func.check.install.pkg('gamlss')
func.check.install.pkg('anomalous')
func.check.install.pkg('oddstream')
func.check.install.pkg('stray')
func.check.install.pkg('sqldf')
func.check.install.pkg('splines')
func.check.install.pkg('changepoint')