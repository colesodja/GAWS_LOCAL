############# ASSIGNS RELATIVE LIKELIHOOD WEIGHTS GIVEN PENALTY 

func.akaike.weights <- function( dfa , penalty ){
#Compute Penalized Deviance
dfe = dfa 
dfe$IC = dfe$Deviance + dfe$edf * penalty
dfe = dfe[order(dfe$IC),]

#find smallest value 
v_best <- min(dfe$IC)

#compute odds 
v_odds = dfe$IC - v_best

#assign weights 
wt <- exp(-.5*v_odds)
wt = wt/sum(wt)
dfe$rel_lik = wt
dfe$log_score = v_odds

return(dfe)
}