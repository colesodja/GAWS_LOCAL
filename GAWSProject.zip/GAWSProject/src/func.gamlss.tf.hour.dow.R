########### R Function to estimate gamlss with following parameters and TF Distribution Family
 #Location:  multiple seasonality using indicators and local level (non-increasing) 
 # Scale: Constant
 # Shape: Constant

func.gamlss.tf.hour.dow <- function( d_y, ...){
### Input:
#d_y - dataframe of time series values y with index Time and identifier ID

###Output: List with elements
#'stat' - dataframe containing modelName, basisName, Degrees of Freedom

#load package 
require(gamlss)
require(splines)
require(MASS)

#create factor variables for Day of Week and Hour of Day
d_y$fDow = as.factor(d_y$Dow)
d_y$fHour = as.factor(d_y$Hour)

## Model 1: Seasonality 
fits = rlm( data = d_y, y ~ fDow*fHour)
S = predict(fits)
S = S-mean(S)

## Model 2: Level|Seasonality
L = d_y$y - S
fitl = loess(L ~ d_y$Seq, span = .8, degree=2)
Lhat = predict(fitl)
nDF = ceiling(fitl$enp)

#if do not improve fit than set level to constant 
fit1 = lm( data = d_y, y ~ S )
fit2 = lm( data = d_y, y ~ S + Lhat)

if(   AIC(fit1) < AIC(fit2) + 2*nDF ){
Lhat = median(L)
nDF = 1
}

#Reset level if continuing upward step (to ensure orthogonal)
z = Lhat-median(Lhat)
posNeg = max( which(z <= .001) )
v_Pos = which( z > .01)
v_Pos = v_Pos[v_Pos > posNeg]

if( length(v_Pos) > 2){
z_pre = z[1:posNeg]
z_post = z[ seq( min(v_Pos), max(v_Pos))] 

if( min(diff(z_post) ) > 0){
Lhat = median(L)
}
}


#compute gamlss model 
dfx = data.frame( y = d_y$y, S, Lhat)
fit = gamlss(data = dfx, 
               y ~ S+Lhat ,
               family = "TF" ,
			   control = gamlss.control(trace = FALSE)
)

#Compute statistics and output
d_stat = data.frame(N = nrow(d_y))
d_stat$Deviance = deviance(fit)
d_stat$edf = nDF + length(coef(fits))
d_stat$modelFamily = "log_tf_season_level"

#Output list 
l_m = list()
l_m$stat = d_stat

#return list
return(l_m)
} 

