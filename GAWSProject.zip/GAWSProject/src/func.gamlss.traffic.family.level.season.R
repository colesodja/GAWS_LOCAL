########### R Function to estimate gamlss with following parameters and TF Distribution Family
 #Location: loess level+fourier basis+ pulse
 #Scale: season basis function
 #Shape: constant

func.gamlss.traffic.family.level.season <- function( d_y, l_parm = list(nFourierBasis=60), ...){
### Input:
#d_y - dataframe of time series values y with index Time and identifier ID
#list with arguments including: nFourierBasis

###Output: List with elements
#'stat' - dataframe containing modelName, basisName, Degrees of Freedom
#'location' - list with name and matrix containing sample paths for location parameter
#'scale' -  list with name and  matrix containing sample paths for scale parameter (if exist)
#'nu' - list with name and matrix containing sample paths for nu parameter (if exist)
#'residuals' -  quantile residuals 
#'par' - dataframe with  hyperparameters

#load package 
require(gamlss)
require(splines)
require(forecast)

#add time sequence
d_y$Seq = 1:nrow(d_y)

#Look-up time series frequency
Y = ts( d_y$y, frequency = 24*7*2  )

#Fit Fourier Basis
X = fourier(Y, K= l_parm$nFourierBasis )[,]
fits = lm(  Y ~ X )
S = predict(fits)
S = S-mean(S)

#Get partial residuals|S and compute level
z = ts(Y-S)
fitl = loess( z ~ d_y$Seq, span=.66, degree=1)
l = predict(fitl)

 #Flag extremes and re-estimate season
 e = z-l
 e= e/mad(e)
 x_pulse = as.factor( ifelse( abs(e) >=5,d_y$Seq,0))

if( length(unique(x_pulse))==1 ){
      x_pulse = as.factor( ifelse( Y == max(Y),1,0 ))
}
    
fits = lm( Y ~ l + x_pulse)
S = Y - predict(fits)

X = fourier(S, K= l_parm$nFourierBasis )[,]
fits = lm(  S ~ X )
S = predict(fits)
S = S-mean(S)

#Compute Remainder
fit2 = lm( Y ~ l + x_pulse + S)
yhat = predict(fit2)
e = fit2$residuals/sd(fit2$residuals)

#Re-flag outliers
x_pulse = as.factor( ifelse( abs(e) >= 5, d_y$Seq,0 ) )
  
if( length(unique(x_pulse))==1 ){
    x_pulse = as.factor( ifelse( Y == max(Y),1,0 ))
}

#Compute lag 
z_lag = ifelse(  abs(e) >= 5, 0 , e) 
z_lag = c(0, z_lag[seq(1, length(z_lag)-1)] )

##fit gamlss 
dfx = data.frame( Y, S, l, x_pulse, z_lag)
fit = gamlss(data = dfx, 
               Y ~ z_lag + l +S, 
               sigma.formula = ~ pb(S, degree=1, df=1),
               nu.formula = ~l,
               family = "TF" ,
			   control = gamlss.control(trace = FALSE)
)


#lookup parameter estimates
v_f = predictAll(fit,  data = dfx)

#produce dataframe with statistics 
numRow = nrow(d_y)
numCol = length( unique(d_y$ID))
basisName = "traffic_season_level_pulse"

d_stat = data.frame(nSeries = numCol)
d_stat$N = nrow(d_y)
d_stat$nTime = length(unique(d_y$Time))
d_stat$Deviance = deviance(fit)
d_stat$edf = l_parm$nFourierBasis + 2+ceiling(AIC(fit)-d_stat$Deviance)/2 -1
d_stat$locationName = "season_level_pulse"
d_stat$distributionFamily = "TF"

#produce matrix with location
l_m = list()
l_m$Location = list( 'locationName' = d_stat$locationName, 'models' = matrix(v_f$mu, nrow = numRow, ncol  = 1) )
l_m$par = data.frame(ParmType = 'location', ParmName =  'season'  , ParmIndex = 1, ParmValue = S)
l_m$par = rbind(l_m$par, data.frame(ParmType = 'location', ParmName =  'level'  , ParmIndex = 1, ParmValue = S) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'location', ParmName =  'basis'  , ParmIndex = 1, ParmValue = v_f$mu ) )

#sigma
y_sig = as.numeric(v_f$sigma)
l_m$Scale = list( 'ScaleName' = "season", 'models' = matrix(y_sig, nrow = numRow, ncol  = numCol) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'scale', ParmName =  'basis'  , ParmIndex = 1, ParmValue = y_sig))
d_stat$ScaleName = "season"

#produce matrix with shape 
y_nu = as.numeric(v_f$nu)
l_m$Shape = list( 'ShapeName' = "level", 'models' = matrix(y_nu, nrow = numRow, ncol  = 1) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'shape', ParmName =  'basis'  ,ParmIndex = 1, ParmValue = y_nu))
d_stat$ShapeName = "level"

#Include modelFamily
d_stat$basisFamily = basisName
d_stat$modelFamily = paste(basisName, "_", "log-TF" , sep='')

#Include functions 
d_stat$basisFunction = "func.gamlss.traffic.family.level.season"
d_stat$likFunction = "func.lik.basis.traffic"

#prepare list 
l_m$basisFamily = basisName 
l_m$distributionFamily = "TF"
l_m$basisFunction = d_stat$basisFunction
l_m$likFunction = d_stat$likFunction 
l_m$data = d_y 
l_m$stat = d_stat
l_m$par$Freq = numCol
l_m$par$basisFamily = d_stat$basisFamily 
l_m$par$modelFamily = d_stat$modelFamily
l_m$residuals = e

#return list
return(l_m)
} 

