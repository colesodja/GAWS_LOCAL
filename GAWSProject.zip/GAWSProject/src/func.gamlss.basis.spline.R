########### R Function to estimate gamlss where Location and Scale are splines and constant Shape, using BCCGo family

func.gamlss.basis.spline <- function( d_y, ...){
### Input:
#d_y - dataframe of time series values y with index Time and identifier ID

###Output: List with elements
#'stat' - dataframe containing modelName, basisName, Degrees of Freedom
#'location' - list with name and matrix containing sample paths for location parameter
#'scale' -  list with name and  matrix containing sample paths for scale parameter (if exist)
#'nu' - list with name and matrix containing sample paths for nu parameter (if exist)
#'residuals' -  quantile residuals 
#'par' - dataframe with  hyperparameters

#load package 
require(gamlss)
require(splines)

#add time sequence
d_y$Seq = 1:nrow(d_y)

#fit spline model to log 
d_y$z = log(1+d_y$y)
fit = lm( data = d_y, z~ bs(Seq, df= 10, degree=1) )
d_y$zhat = predict(fit)

#lookup up residuals and flag if extreme dips
e  =fit$residuals
e = e-mean(e)
e_sd = 1.5*median(abs(e))
e = e/e_sd
v_flag = ifelse( e < -5, 1,0)

#estimate
if( sum(v_flag) > 2){
d_y$flag = as.factor( ifelse(v_flag==1, d_y$Seq, "0"))
fit = gamlss( data = d_y , y ~ zhat+flag,  sigma.formula = ~ pb(Seq, df=2, degree=1), family ="BCCGo", control = gamlss.control(trace = FALSE) )
}else{
fit = gamlss( data = d_y , y ~ zhat,  sigma.formula = ~ pb(Seq, df=2, degree=1), family ="BCCGo", control = gamlss.control(trace = FALSE) )
}

#lookup parameter estimates
v_f = predictAll(fit,  data = d_y)

#produce dataframe with statistics 
numRow=1
numCol = length( unique(d_y$ID))
basisName = "spline_location_scale_shape"

d_stat = data.frame(nSeries = numCol)
d_stat$N = nrow(d_y)
d_stat$nTime = length(unique(d_y$Time))
d_stat$Deviance = deviance(fit)
d_stat$edf = 10+3+2 
d_stat$locationName = "spline"
d_stat$distributionFamily = "BCCGo"

#produce matrix with location
l_m = list()
v_mu = head( v_f$mu, d_stat$nTime)
l_m$Location = list( 'locationName' = d_stat$locationName, 'models' = matrix(v_mu, nrow = d_stat$nTime, ncol  = 1) )
l_m$par = data.frame(ParmType = 'location', ParmName =  ''  , ParmIndex = 1, ParmValue = v_mu)

#sigma
y_sig = as.numeric(v_f$sigma)
l_m$Scale = list( 'ScaleName' = "spline", 'models' = matrix(y_sig, nrow = d_stat$nTime, ncol  = numCol) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'scale', ParmName =  'constant_sigma'  , ParmIndex = 1, ParmValue = y_sig))
d_stat$ScaleName = "spline"

#produce matrix with shape 
y_nu = as.numeric(v_f$nu[1])
l_m$Shape = list( 'ShapeName' = "constant", 'models' = matrix(y_nu, nrow = 1, ncol  = 1) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'shape', ParmName =  'constant_nu'  ,ParmIndex = 1, ParmValue = y_nu))
d_stat$ShapeName = "constant"

#Include modelFamily
d_stat$basisFamily = basisName
# d_stat$modelFamily = paste(basisName, "_", "BCCGo", "_series", paste(unique(d_y$ID), collapse=";") , sep='')
 d_stat$modelFamily = paste(basisName, "_", "BCCGo" , sep='')

#Include functions 
d_stat$basisFunction = "func.gamlss.basis.spline"
d_stat$likFunction = "func.lik.spline.bccgo"

#prepare list 
l_m$basisFamily = basisName 
l_m$distributionFamily = "BCCGo"
l_m$basisFunction = d_stat$basisFunction
l_m$likFunction = d_stat$likFunction 
l_m$data = d_y 
l_m$stat = d_stat
l_m$par$Freq = numCol
l_m$par$basisFamily = d_stat$basisFamily 
l_m$par$modelFamily = d_stat$modelFamily
l_m$residuals = e

return(l_m)
} 

