############# Computes the excess rank performance measure  per each method 

## Input: 
#d_result - dataframe with columns: Method	fScore N	excess_rank	excess_rank_abs	ExperimentName	numAnomaly	AnomalyID	numSubspace

## Output: dataframe with average performance per method/statistic

func.perf <- function( d_result ){
#compute  mean excess_rank, excess_rank_abs, fScore per method 
d_result$fScore = ifelse(  is.na(d_result$fScore ), 0 , d_result$fScore )
d_stat = aggregate(data = d_result, cbind(fScore, excess_rank, excess_rank_abs) ~ Method, mean)

#transpose
d_p = data.frame()
v_M = unique(d_stat$Method)

for( v in v_M){
posV = which(v == v_M)
dfp = subset(d_stat, Method == v)[, 2:ncol(d_stat)]
#v_T  = t(dfp)[,1]
#dfp = data.frame(Statistic = names(v_T), X  = as.numeric(v_T ) )
#colnames(dfp)[2] = v 
colnames(dfp) = paste( v, "_", colnames(dfp), sep='')

if( posV >1){
d_p = cbind(d_p, dfp)
#dfp =  as.data.frame(dfp[,2])
#colnames(dfp) = v 
#d_p = cbind(d_p, dfp)
} else{
#d_p = dfp
d_p = dfp
}
}



#add additional statistics and output
d_info = unique( d_result[, c("ExperimentName","N","numAnomaly", "numSubspace") ] )
d_info = merge(d_info, d_p)
return(d_info)
}
