############# Produces sample path Drawn from Random Walk with Drift assuming Gaussian Errors

func.sim.rwd <- function( N,  e_sd, b, ...){
##Input:
 #N is an integer defining number of time points
 #e_sd is the standard deviation, assumed constant
 #b is constant drift value

## Output: sample path 

#first draw iid zero mean Gaussian random variables
r = rnorm( N, 0, e_sd)

## loop thru each time point, updating process sequentially
l_prev = 0
x_sim = c()

for( i in 1:N){
z = r[i]
x_sim = c( x_sim, l_prev + z )
l_prev = l_prev + b
}

#output
return(x_sim)
}
