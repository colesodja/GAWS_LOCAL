########### Function to generate simulations from noise with random pulses given parameters

func.sim.pulse <- function(d_time, l_par , ...){
#lookup error
e = d_time$e

#lookup how many pulses to include
n_pulse = l_par$n_pulse 

#time sequence
v_seq = d_time$Time

# randomly assign pulse
#prob_spike = n_pulse/length(v_seq)
#v_flag = rbinom(n = length(v_seq), size = 1, prob = prob_spike)
v_flag = sample(v_seq,size=n_pulse, replace = FALSE)
v_seq_flag = ifelse( v_seq %in% v_flag,1,0) 

#generate lift 
v_lift = runif( n_pulse, l_par$shift_ran[1], l_par$shift_ran[2])
x = rep(0,length(v_seq))
x[v_flag] <- v_lift

#output
y = x+e
return(list('model' = "random_pulse", 'y' = y, 'x' = x) )
}
