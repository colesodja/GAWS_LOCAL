
############# GAMLSS-AKAIKE-WEIGHTS-SCORING  R Function - Multiple Univariate Series Looping 
## Description:
#Assumes all needed packages are installed
#Assumes data is sufficiently small enough to fit in memory and amenable for running the RS-algorithm
#Assumes all functions are already sourced
 #dependent on: func.akaike.weights
 #dependent on class of functions with abbreviations "func.gamlss."

## Input: 
#dfy - dataframe of time series values y with index Time and identifier ID
#l_Family - list of bases families arguments
#maxRank  - scalar defining the maximum number of time series to return based on ranking of lowest likelihood scores

## Output: dataframe  time series identifier Col, rank, and score

func.gaws.univariate.loop.use.par <- function( dfy, l_Family,  maxRank , printON = FALSE , ...){
#packages 
require(sqldf)

#list of time series 
v_j = unique(dfy$ID)

#lookup basis function names
l_b = l_Family$l_bases
v_bases = names(l_b)

#minimum relative likelihood to be considered a potential model
minLik = ifelse( is.null( l_Family$parm$minLik), 1/1000,  l_Family$parm$minLik)

#dataframes for appending
d_parm = data.frame()
d_stat = data.frame()

### PART 1 -  1st Time Series Loop to Estimate All Models (should be  cloud distributed!)
for( j in v_j ){

if( printON ){
  print(j)
 } 
  
  #subset to time series and build dataframe
  d_y = subset(dfy, ID == j)
  d_m_s = data.frame()
  d_m_p = data.frame()
 
 ## loop thru each modelFamily (could also be distributed if many families)
  for( b in v_bases ){
    #subset to basis info 
    pos = which( v_bases == b)
    l_info = l_b[[pos]]
    l_info$basisFamily = b
    
    #create list of parameters 
    l_parm = c(l_Family$parm,  list('distributionFamily' = l_info$distributionFamily), l_info$arg)
    
    #run model (ignoring any error if raised)
    l_m = tryCatch( get(l_info$basisFunction)( d_y, l_parm), error = function(e) list() ) 
	
	#append if exists
	if( length(l_m) >0){
    d_p = l_m$par
    d_p$ID = j
    d_p$modelID = paste(d_p$modelFamily,"_",j, sep='')
	d_p$edf = l_m$stat$edf
	d_m_p = rbind(d_m_p, d_p)
	
	d_s = l_m$stat 
	d_s$ID = j
	d_m_s = rbind(d_m_s, d_s)
   }	

  } #end of models loop
  
#compute Akaike weights 
d_wt  = func.akaike.weights( d_m_s, penalty = log(nrow(d_y) ) ) 

# append
d_stat =   rbind( d_stat , d_wt )
d_parm =   rbind(d_parm, d_m_p)
} #end of time series loop


#####  PART 2 -  Form Model Space per ModelFamily
#for local version just sample
d_modelSpace = data.frame()
v_MF = unique(d_parm$modelFamily)
nSample = ifelse( is.null(l_Family$parm$nSample) , .2*length(v_j),  l_Family$parm$nSample)

for(  mf in v_MF){
#subset 
d_p = subset(d_parm, modelFamily == mf)

#randomly sample series 
v_si = unique( d_p$ID)
N = pmin( length(v_si), nSample)
v_sampleID = sample( v_si, N)

#append 
d_modelSpace = rbind(d_modelSpace, subset(d_p, ID %in% v_sampleID) )
} 

#####  PART 3 -  2nd Series Loop To assess Relative Penalized Likelihood Score|Models  (should be  cloud distributed!)
d_lik = data.frame()

for( j in v_j ){
#subset to series and models
d_y = subset( dfy , ID == j)
d_models_y = subset(d_parm, ID==j)

## loop thru each modelFamily and compute likelihood 
v_mf = unique(d_models_y$modelFamily)
d_m  = data.frame()

for( mf in v_mf ){
 #subset to model for series and all others
  d_basis1  = subset(d_models_y,  ID ==j & modelFamily == mf )
  d_basis0 = subset(d_modelSpace , modelFamily == mf & !(ID==j))
 
 #lookup likelihood function 
  b = unique(d_basis1$basisFamily)
  l_parm = c(l_Family$parm,l_b[[pos]])
  func.lik.mf = l_parm$likFunction
  
  #compute penalized likelihood across models and alternative
  d_l = get(func.lik.mf)( d_y, d_basis0, d_basis1, l_parm, penalty = log( nrow(d_y) ))
  
 #append 
 if( nrow(d_l) >0 ){
 d_l$ID = j
  d_m = rbind( d_m, d_l)
 } 
 } #end of models loop
 
 #compute Akaike Weights 
 d_wt  = func.akaike.weights( d_m, penalty = log(nrow(d_y) ) )
 d_lik = rbind( d_lik, d_wt)

} #end of outer loop 


#lookup minumum number of unique time series per subspace 
minObsSubspace =  ifelse( is.null( l_Family$parm$minObsSubspace), pmax(10,.01*length(v_j)),   l_Family$parm$minObsSubspace )

#form probable subspaces per modelFamily
d_lik$subspaceFamily = paste(d_lik$modelFamily,d_lik$isNormal)
d_subspace = subset(d_lik, rel_lik > minLik & isNormal=="Y" )
d_subspace = sqldf('Select modelFamily, count(distinct ID) as N from d_subspace group by 1')

#confirm subspace exists and #assign "normal" subspaces as having minimum frequency
if( nrow(d_subspace) == 0 ){
d_subspace = subset(d_lik, rel_lik > minLik  )
d_subspace = sqldf('Select modelFamily, count(distinct ID) as N from d_subspace group by 1')
d_subspace  = subset(d_subspace, N > minObsSubspace)
d_subspace$likSubspace = d_subspace$N/sum(d_subspace$N)
d_score = d_lik
d_score$isNormal = ifelse( d_score$modelFamily %in%  d_subspace$modelFamily, "Y", "N")
} else{
d_score = subset(d_lik,  isNormal=="Y" )
d_subspace$likSubspace = d_subspace$N/sum(d_subspace$N)
}

#merge 
d_score = merge(d_score, d_subspace, by = "modelFamily")
d_score$weightLik = d_score$rel_lik * d_score$likSubspace

#First Pass - identify IDs that are anomalous and create models exclusion list
d_score2 = subset(d_score, isNormal=="Y")
d_s = sqldf('Select ID as Col, sum(rel_lik) as Prob from d_score2 group by 1 order by 2')

if(  max(d_s$Prob) <  minLik){
d_s = sqldf('Select ID as Col, sum(rel_lik) as Prob from d_score group by 1 order by 2')
}

d_m = subset( d_s, Prob < minLik)
v_mID = apply( d_score[,c('modelFamily','modelID')], 1, function(M)  attr( regexpr( M[1], M[2]), "match.length") ) 
d_s = data.frame( modelID =  d_score$modelID, Pos = v_mID)
mID = apply(d_s, 1,  function(S) substr(S[1], as.numeric(S[2])+2, nchar(S[1]))  ) 
mID = as.integer(mID)
d_score$mID = mID
d_ok = subset( d_score, !( mID %in% d_m$Col) )

#Second Pass - remove anomlaous IDs and re-compute probability of each subspace per ID and rank
d_score = sqldf('Select ID as Col, sum(rel_lik) as Prob,  sum(weightLik) as wtProb from d_ok group by 1 order by 3')
d_score$Rank = 1:nrow(d_score)

#return dataframe
return(d_score)
}
