############# Produces sample path Drawn from zero mean AR(P,phi, e_0, e_sd) process assuming Gaussian Errors

func.sim.ar <- function( N, e_0, e_sd, ar_coef , ...){
##Input:
 #N is an integer defining number of time points
 #e_0 is the vector of initial starting values of time series per each lag
 #e_sd is the standard deviation, assumed constant
 #ar_coef is a vector of AR coefficients

## Output: sample path 

#first draw iid zero mean Gaussian random variables
r = rnorm( N, 0, e_sd)

## loop thru each time point, updating process sequentially
e_prev = e_0
x_sim = c()
 
for( i in 1:N){
#lookup iid error
z = r[i]  
  
#compute lag terms and sum
M = i + length(e_0)
x_k = c()

for( k in 1:length(e_0) ){
x_k = c(x_k, ar_coef[k] * e_prev[M-k] )
}
  
#update 
x = sum(x_k) + z
x_sim = c(x_sim, x)
e_prev = c(e_prev, x) 
}


#output
return(x_sim)
}
