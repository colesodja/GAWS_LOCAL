########### R Function to estimate model where Location Stationary AR(p) and Constant Scale/Shape

###NOTES:
#Maximum order of autoregressive term is 2 (chosen for simulation data)

func.gamlss.basis.ar <- function( d_y, l_parm , ...){
### Input:
#d_y - dataframe of time series values y with index Time and identifier ID
#l_parm - list with parameters, including distributionFamily

###Output: List with elements
#'stat' - dataframe containing modelName, basisName, Degrees of Freedom
#'location' - list with name and matrix containing sample paths for location parameter
#'scale' -  list with name and  matrix containing sample paths for scale parameter (if exist)
#'nu' - list with name and matrix containing sample paths for nu parameter (if exist)
#'residuals' -  quantile residuals 
#'par' - dataframe with  hyperparameters

#load package 
require(gamlss)

#lookup distribution, default to Gaussian 
v_family  = ifelse(  is.null( l_parm$distributionFamily), "NO", l_parm$distributionFamily )


## Loop thru each time series and extract lags
v_id = unique( d_y$ID)
d_data = data.frame()
v_ar = c()

for( v in v_id){
#lookup log time series
dfv = subset(d_y, ID==v)
y = dfv$y
z = ts( log(y+1), frequency = 1)

#check if stationary process using auto.arima test 
fita = auto.arima( z, max.q=0, max.p = 2, seasonal = FALSE)
arimaDiff = fita$arma[6]

if(  arimaDiff  == 0 & fita$arma[1] >0 ){

#create indicators
y_l1 = median( head(z,5)) 
y_l2 = median( head(z,10)) 
y_l3 = median( head(z,20)) 

#lag1 
dfv$y_lag1 = c( y_l1, z[ seq(1, length(z)-1) ] ) 

#lag2 
dfv$y_lag2 = c( y_l2, y_l1, z[ seq(1, length(z)-2) ] ) 

#lag3
dfv$y_lag3= c( y_l3, y_l2, y_l1, z[ seq(1, length(z)-3) ] ) 

#append
d_data = rbind(d_data, dfv)
}
} 


## attempt to fit gamlss models
if( nrow(d_data) >0 ){ 
#lag1
fit1 = gamlss( data = d_data, y ~ 1+y_lag1, family =v_family, control = gamlss.control(trace = FALSE) )

#lag2
fit2 = gamlss( data = d_data, y ~ 1+y_lag1+y_lag2, family =v_family, control = gamlss.control(trace = FALSE) )

#assign best model
if( BIC(fit2) < BIC(fit1) ){
fit = fit2
} else{
fit = fit1
} 

#lookup parameter estimates	and ar coef	
v_f = predictAll(fit,  data = d_data, se.fit = TRUE)
v_coef = coef(fit)
v_coef = as.numeric( v_coef[2:length(v_coef)] )

#produce dataframe with statistics 
numRow= l_parm$mRows
numCol = length( unique(d_y$ID))
basisName = "ar_constant"

d_stat = data.frame(nSeries = numCol)
d_stat$N = nrow(d_y)
d_stat$nTime = length(unique(d_y$Time))
d_stat$Deviance = deviance(fit)
d_stat$edf = ceiling(AIC(fit)-d_stat$Deviance)/2   #estimates for location, scale and shape parm
d_stat$locationName = "gamlss_ar_"
d_stat$distributionFamily = v_family 

#produce matrix with location
l_m = list()
v_mu = head( v_f$mu$fit, d_stat$nTime)
l_m$Location = list( 'locationName' = d_stat$locationName, 'models' = matrix(v_mu, nrow = d_stat$nTime, ncol  = 1) )

#Add AR parameters
l_m$par = data.frame(ParmType = 'location', ParmName =  'ar'  , ParmIndex = 1:length(v_coef), ParmValue = v_coef)


#produce matrix with scale (if exist)
if( "sigma" %in% names(v_f) ){
y_sig = as.numeric(v_f$sigma$fit[1])
y_sig_sd = as.numeric(v_f$sigma$se.fit[1])
v_sig= exp( log(rnorm( numCol, y_sig, y_sig_sd)))
l_m$Scale = list( 'ScaleName' = "constant", 'models' = matrix(v_sig, nrow = 1, ncol  = numCol) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'scale', ParmName =  'constant_sigma'  , ParmIndex = 1, ParmValue = y_sig))
l_m$par = rbind(l_m$par, data.frame(ParmType = 'scale', ParmName =  'constant_sigma_sd'  , ParmIndex = 1, ParmValue = y_sig_sd))
basisName =  "ar_constant_scale"
d_stat$ScaleName = "constant"
} else{
l_m$Scale = list()
d_stat$ScaleName = "NULL"
}


#produce matrix with shape (if exist)
if( "nu" %in% names(v_f) ){
y_nu = as.numeric(v_f$nu$fit[1])
y_nu_sd = as.numeric(v_f$nu$se.fit[1])
v_nu=  rnorm( numCol, y_nu, y_nu_sd)
l_m$Shape = list( 'ShapeName' = "constant", 'models' = matrix(v_nu, nrow = 1, ncol  = numCol) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'shape', ParmName =  'constant_nu'  ,ParmIndex = 1, ParmValue = y_nu))
l_m$par = rbind(l_m$par, data.frame(ParmType = 'shape', ParmName =  'constant_nu_sd'  , ParmIndex = 1,ParmValue = y_nu_sd))
basisName =  "ar_constant_scale_shape"
d_stat$ShapeName = "constant"
} else{
l_m$Shape= list()
d_stat$ShapeName = "NULL"
}

#Include modelFamily
d_stat$basisFamily = basisName
d_stat$modelFamily = paste(basisName, "_", l_parm$distributionFamily, sep='')

#Include functions 
d_stat$basisFunction = "func.gamlss.basis.ar"
d_stat$likFunction = "func.lik.ar"

#prepare list 
l_m$basisFamily = basisName 
l_m$distributionFamily = v_family 
l_m$basisFunction = d_stat$basisFunction
l_m$likFunction = d_stat$likFunction 
l_m$data = d_y 
l_m$stat = d_stat
l_m$par$Freq = numCol
l_m$par$basisFamily = d_stat$basisFamily 
l_m$par$modelFamily = d_stat$modelFamily
l_m$residuals = fit$residuals
} else{
l_m = list()
}


return(l_m)
} 

