########### R Function to estimate gamlss where Parm are penalized splines of BCCGo family

func.gamlss.basis.pb.bccgo <- function( d_y, ...){
### Input:
#d_y - dataframe of time series values y with index Time and identifier ID

###Output: List with elements
#'stat' - dataframe containing modelName, basisName, Degrees of Freedom
#'location' - list with name and matrix containing sample paths for location parameter
#'scale' -  list with name and  matrix containing sample paths for scale parameter (if exist)
#'nu' - list with name and matrix containing sample paths for nu parameter (if exist)
#'residuals' -  quantile residuals 
#'par' - dataframe with  hyperparameters

#load package 
require(gamlss)
require(splines)

#add time sequence
d_y$Seq = 1:nrow(d_y)

#fit spline model to log, testing edf
d_y$z = log(1+d_y$y)
fit3 = lm( data = d_y, z ~ bs(Seq, df= 100, degree=1) ) 
fit2 = lm( data = d_y, z ~ bs(Seq, df= 50, degree=1) ) 
fit1 = lm( data = d_y, z ~ bs(Seq, df= 25, degree=1) ) 
fit0 = lm( data = d_y, z ~ bs(Seq, df= 5, degree=1) ) 

v_bic = c()
l_fits = list('0' = fit0, '1' = fit1, '2' = fit2, '3' = fit3)

for( k in 1:4){
v_bic = c( v_bic, BIC(l_fits[[k]]) )
}

posBIC = which( v_bic == min(v_bic) )[1]

#assign initial mean basis
fit_b = l_fits[[posBIC]]
d_y$zhat = predict(fit_b)

#lookup up residuals and flag if extremes 4 sigma
e  = fit_b$residuals
e = e-mean(e)
e_sd = 1.5*median(abs(e))
e = e/e_sd
v_flag = ifelse( e < -3.5, 1,0)

#estimate
if( sum(v_flag) > 0){
d_y$flag = as.factor( ifelse(v_flag==1, d_y$Seq, "0"))
fit = tryCatch( gamlss( data = d_y , y ~ pbz(Seq,degree=1)+flag,  sigma.formula = ~ pbz(Seq, degree=2), nu.formula = ~ pbz(Seq, degree=1),
                 family ="BCCGo", control = gamlss.control(trace = FALSE) ), error = function(e) NULL)
}else{
fit = tryCatch( gamlss( data = d_y , y ~ pbz(Seq,degree=1),  sigma.formula = ~ pbz(Seq, degree=2), nu.formula = ~ pbz(Seq, degree=1),
                 family ="BCCGo", control = gamlss.control(trace = FALSE) ), error = function(e) NULL)
}

#attempt to re-estimate if failed using fixed spline and constant scale/shape 
if( is.null(fit) ){
fit = gamlss( data = d_y , y ~ zhat, family ="BCCGo", control = gamlss.control(trace = FALSE) )
nDF = length( coef(fit_b) )
} else{
nDF = 2
}

#lookup parameter estimates
v_f = predictAll(fit,  data = d_y)

#produce dataframe with statistics 
numRow = length(unique(d_y$Time))
numCol = length( unique(d_y$ID))
basisName = "spline_location_scale_shape_bccgo"

d_stat = data.frame(nSeries = numCol)
d_stat$N = nrow(d_y)
d_stat$nTime = length(unique(d_y$Time))
d_stat$Deviance = deviance(fit)
d_stat$edf = pmax(nDF, ceiling(AIC(fit)-d_stat$Deviance)/2 -1)
d_stat$locationName = "spline"
d_stat$distributionFamily = "BCCGo"

#produce matrix with location
l_m = list()
v_mu = head( v_f$mu, d_stat$nTime)
l_m$Location = list( 'locationName' = d_stat$locationName, 'models' = matrix(v_mu, nrow = d_stat$nTime, ncol  = 1) )
l_m$par = data.frame(ParmType = 'location', ParmName =  'mu_basis_pbz'  , ParmIndex = 1, ParmValue = v_mu)

#sigma
y_sig = as.numeric(v_f$sigma)
l_m$Scale = list( 'ScaleName' = "spline", 'models' = matrix(y_sig, nrow = d_stat$nTime, ncol  = numCol) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'scale', ParmName =  'sigma_basis_pbz'  , ParmIndex = 1, ParmValue = y_sig))
d_stat$ScaleName = "spline"

#produce matrix with shape 
y_nu = as.numeric(v_f$nu)
l_m$Shape = list( 'ShapeName' = "constant", 'models' = matrix(y_nu, nrow = d_stat$nTime, ncol  = 1) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'shape', ParmName =  'nu_basis_pbz'  ,ParmIndex = 1, ParmValue = y_nu))
d_stat$ShapeName = "constant"

#Include modelFamily
d_stat$basisFamily = basisName
 d_stat$modelFamily = paste(basisName, "_", "BCCGo" , sep='')

#Include functions 
d_stat$basisFunction = "func.gamlss.basis.pb.bccgo"
d_stat$likFunction = "func.lik.spline.bccgo"

#prepare list 
l_m$basisFamily = basisName 
l_m$distributionFamily = "BCCGo"
l_m$basisFunction = d_stat$basisFunction
l_m$likFunction = d_stat$likFunction 
l_m$data = d_y 
l_m$stat = d_stat
l_m$par$Freq = numCol
l_m$par$basisFamily = d_stat$basisFamily 
l_m$par$modelFamily = d_stat$modelFamily
l_m$residuals = e

## add model cluster info for later building subfamilies
v_a = coef(fit_b)
d_clus = d_stat
d_clus$LocationEDF = length(v_a)

# check if location roughly constant 
Mu = log(1+v_mu)
Mu = Mu - mean(Mu)

if(  quantile(Mu,.975) - quantile(Mu,.025)  < .01 ){
d_clus$locationName = "constant"
} 

#check if sigma constant up to .005
Sig = ceiling( y_sig/.005)*.005

if( min(Sig) == max(Sig) ){
d_clus$ScaleName = "constant"
d_clus$ScaleEDF = 1
}  else{
d_clus$ScaleEDF = length(unique(Sig))
}

#check if nu constant 
Nu = ceiling( y_nu/.01)*.01

if( min(Nu) == max(Nu) ){
d_clus$ShapeName = "constant"
d_clus$ShapeEDF = 1
}  else{
d_clus$ShapeEDF= length(unique(Nu))
}

#add cluster label 
d_clus$Clus = paste( d_clus$modelFamily, d_clus$locationName, d_clus$ScaleName, d_clus$ShapeName)
l_m$modelClus = list( 'clus' = d_clus, 'location' = v_a , 'scale'  = y_sig, 'shape' = y_nu ) 

#return list
return(l_m)
} 

