########### Function to generate simulations from local-level univariate time series model given initial parameters and innovation

func.sim.local.level <- function(d_time, l_par , ...){
#lookup error
e = d_time$e

## loop thru each time, updating level 
l_smooth = l_par$l_smooth

l_prev = l_par$l0
L = c()

for( i in seq(   nrow(d_time) ) ){
 l = l_prev + l_smooth * e[i]
 L = c(L,l)
 l_prev = l
}

y = ts( L+e)

return(list('model' = "local_level", 'y' = y, 'l' = L) )
}
