########### R Function to estimate gamlss where Location constant and scale has monotonic spline

func.gamlss.basis.scale.spline <- function( d_y, ...){
### Input:
#d_y - dataframe of time series values y with index Time and identifier ID

###Output: List with elements
#'stat' - dataframe containing modelName, basisName, Degrees of Freedom
#'location' - list with name and matrix containing sample paths for location parameter
#'scale' -  list with name and  matrix containing sample paths for scale parameter (if exist)
#'nu' - list with name and matrix containing sample paths for nu parameter (if exist)
#'residuals' -  quantile residuals 
#'par' - dataframe with  hyperparameters

#load package 
require(gamlss)
require(splines)

#add time sequence
d_y$Seq = 1:nrow(d_y)

#lookup distribution, default to Gaussian 
v_family  = ifelse(  is.null( l_parm$distributionFamily), "NO", l_parm$distributionFamily )

#estimate
fit = gamlss( data = d_y , y ~1, sigma.formula = ~ pbm(Seq, df=3, degree=1), family = v_family, control = gamlss.control(trace = FALSE) )

#lookup parameter estimates
v_f = predictAll(fit,  data = d_y)

#produce dataframe with statistics 
numRow=1
numCol = length( unique(d_y$ID))
basisName = "constant_location_scale_trend"
d_stat = data.frame(nSeries = numCol)
d_stat$N = nrow(d_y)
d_stat$nTime = length(unique(d_y$Time))
d_stat$Deviance = deviance(fit)
d_stat$edf = pmax(2, ceiling(AIC(fit)-d_stat$Deviance)/2) +1
d_stat$locationName = "constant"
d_stat$distributionFamily = v_family

#produce matrix with location
l_m = list()
v_mu = head( v_f$mu,1)
l_m$Location = list( 'locationName' = d_stat$locationName, 'models' = matrix(v_mu, nrow = 1, ncol  = 1) )

#sigma
y_sig = as.numeric(v_f$sigma)
l_m$Scale = list( 'ScaleName' = "constant", 'models' = matrix(y_sig, nrow = length(y_sig), ncol  = 1) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'scale', ParmName =  'spline'  , ParmIndex = 1, ParmValue = y_sig))
d_stat$ScaleName = "spline"

#shape 
if( "nu" %in% names(v_f) ){
y_nu = as.numeric(v_f$nu[1])
l_m$Shape = list( 'ShapeName' = "constant", 'models' = matrix(y_nu, nrow = 1, ncol  = numCol) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'shape', ParmName =  'constant_nu'  , ParmIndex = 1, ParmValue = y_nu))
basisName = "constant_location_shape_trend_scale"
d_stat$ShapeName = "constant"
} else{
l_m$Shape= list()
d_stat$ShapeName = "NULL"
}


#Include modelFamily
d_stat$basisFamily = basisName
d_stat$modelFamily = paste(basisName, "_", v_family, sep='')

#Include functions 
d_stat$basisFunction = "func.gamlss.basis.scale.spline"
d_stat$likFunction = "func.lik.scale.spline"

#prepare list 
l_m$basisFamily = basisName 
l_m$distributionFamily = v_family
l_m$basisFunction = d_stat$basisFunction
l_m$likFunction = d_stat$likFunction 
l_m$data = d_y 
l_m$stat = d_stat
l_m$par$Freq = numCol
l_m$par$basisFamily = d_stat$basisFamily 
l_m$par$modelFamily = d_stat$modelFamily
l_m$residuals = fit$residuals

return(l_m)
} 

