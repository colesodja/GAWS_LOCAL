############# Computes the excess rank performance measure  per each method 

## Input: 
#d_rank - dataframe containing Col (identifier of time series), Rank (lower -> anomaly), Method (name of anomaly detector), isAnomaly
#N - scalar specifying number of time series 
#numAnomaly - scalar specifying number of anomalous series

## Output: dataframe with excess rank measure per method

func.excess.rank <- function( d_rank, N, numAnomaly ){
#subset to anomalies 
d_a = subset(d_rank, isAnomaly == 1)

#compute maximum rank per method 
d_perf = aggregate(data = d_a, Rank ~ Method, max)
colnames(d_perf)[2] = "maxRank"

#compute amount of excess rank relative to actual number of anomalies
p = numAnomaly/N
d_perf$N = N 
d_perf$p = p
d_perf$excess_rank = p - d_perf$maxRank/N
d_perf$excess_rank_abs = abs( d_perf$excess_rank)

#return dataframe 
return(d_perf)
}
