########### Function to Call Stray Algorithm for detecting anomalous series

func.stray.detection <- function( Y1, numAlarm = 1 , ...){
#load package 
require(oddstream)
require(stray)

#compute features of time series
tsfeatures <- oddstream::extract_tsfeatures(Y1)

#find anomalous time series features 
A <- find_HDoutliers(tsfeatures, alpha = .1,  k = 1 , knnsearchtype = "brute")

#Lookup Ranking 
dfr = data.frame(Col = 1:ncol(Y1), Score = A$out_scores)
dfr = dfr[order(-dfr$Score),]
dfr$Rank = 1:nrow(dfr)
dfr$Model = 'stray'

#return dataframe with ranking
return(dfr)
} 