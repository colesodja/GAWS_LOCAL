########### R Function to estimate model with Stationary Local Level+ Pulse for location and Constant Scale/Shape

func.gamlss.basis.level.pulse <- function( d_y, l_parm , ...){
### Input:
#d_y - dataframe of time series values y with index Time and identifier ID
#l_parm - list with parameters, including distributionFamily

###Output: List with elements
#'stat' - dataframe containing modelName, basisName, Degrees of Freedom
#'location' - list with name and matrix containing sample paths for location parameter
#'scale' -  list with name and  matrix containing sample paths for scale parameter (if exist)
#'nu' - list with name and matrix containing sample paths for nu parameter (if exist)
#'residuals' -  quantile residuals 
#'par' - dataframe with  hyperparameters

#load package 
require(gamlss)
require(forecast)

#lookup distribution, default to Gaussian 
v_family  = ifelse(  is.null( l_parm$distributionFamily), "NO", l_parm$distributionFamily )

#lookup confLevelOutlier
confLevelOutlier = ifelse(  is.null( l_parm$confLevelOutlier), 1/1000, l_parm$confLevelOutlier )

## Loop thru each time series and fit ets ANN model on log-scale 
v_id = unique( d_y$ID)
d_data = data.frame()

for( v in v_id){
dfv = subset(d_y, ID==v)
dfv$z = ts( log(1+dfv$y), frequency = 1) #log scale

#check mean stationarity and if not then use median as level
fita = auto.arima( dfv$z, max.q=0, max.p = 1, seasonal = FALSE)
arimaDiff = fita$arma[6]

if(  arimaDiff  == 0  ){
#fit ets 
fite = ets(dfv$z , model = 'ANN')
dfv$yhat = fitted(fite)
dfv$alpha = as.numeric(fite$par[1])
} else{
dfv$yhat  = median(z)
dfv$alpha  = 0
}

d_data = rbind(d_data, dfv)
}

#get preliminary outlier estimate 
e = d_data$z - d_data$yhat
e = e-mean(e)
e_sd = 1.5*median(abs(e))
e = e/e_sd
v_p = 1-pnorm(e)
v_flag = ifelse( v_p < l_parm$confLevelOutlier, 1,0)

if(  sum(v_flag) > 0 ){
d_data$Seq = 1:nrow(d_data)
d_data$flag = as.factor(  ifelse(v_flag==1,d_data$Seq , 0))
fit = gamlss( data = d_data, y ~ 1+yhat + flag , family =v_family, control = gamlss.control(trace = FALSE) )
} else{
fit = gamlss( data = d_data, y ~ 1+yhat  , family =v_family, control = gamlss.control(trace = FALSE) )
}					

#lookup parameter estimates			
v_f = predictAll(fit,  data = d_data, se.fit = TRUE)

#produce dataframe with statistics 
numRow= l_parm$mRows
numCol = length( unique(d_y$ID))
basisName = "level_pulse"

d_stat = data.frame(nSeries = numCol)
d_stat$N = nrow(d_data)
d_stat$nTime = length(unique(d_y$Time))
d_stat$Deviance = deviance(fit)
d_stat$edf = ceiling(AIC(fit)-d_stat$Deviance)/2  + 2 #estimates for location, scale and shape parm
d_stat$locationName = "gamlss_level_pulse_"
d_stat$distributionFamily = v_family 

#produce matrix with location
l_m = list()
v_mu = v_f$mu$fit
y_mu = ifelse( v_flag==1, median(v_mu), v_mu)
v_alpha = unique(d_data$alpha)
l_m$Location = list( 'locationName' = d_stat$locationName, 'models' = matrix(v_mu, nrow = d_stat$nTime, ncol  = numCol) )
l_m$par = data.frame(ParmType = 'location', ParmName =  'constant_mu'  , ParmIndex = 1, ParmValue = median(v_mu) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'location', ParmName =  'alpha'  , ParmIndex = 1, ParmValue = v_alpha))

#lookup pulse and location
if( sum(v_flag) > 0 ){
v_cp = as.numeric(which(v_flag==1))
v_r = as.numeric((v_mu/y_mu)[v_cp])
} else{
v_cp = NA 
v_r = 1
}

l_m$par = rbind(l_m$par, data.frame(ParmType = 'location', ParmName =  'pulse'  , ParmIndex = 1, ParmValue = v_r))
l_m$par = rbind(l_m$par, data.frame(ParmType = 'location', ParmName =  'cp'  , ParmIndex = 1, ParmValue = v_cp))

#produce matrix with scale (if exist)
if( "sigma" %in% names(v_f) ){
y_sig = as.numeric(v_f$sigma$fit[1])
y_sig_sd = as.numeric(v_f$sigma$se.fit[1])
v_sig= exp( log(rnorm( numCol, y_sig, y_sig_sd)))
l_m$Scale = list( 'ScaleName' = "constant", 'models' = matrix(v_sig, nrow = 1, ncol  = numCol) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'scale', ParmName =  'constant_sigma'  , ParmIndex = 1, ParmValue = y_sig))
l_m$par = rbind(l_m$par, data.frame(ParmType = 'scale', ParmName =  'constant_sigma_sd'  , ParmIndex = 1, ParmValue = y_sig_sd))
basisName = "level_pulse_constant_scale"
d_stat$ScaleName = "constant"
} else{
l_m$Scale = list()
d_stat$ScaleName = "NULL"
}


#produce matrix with shape (if exist)
if( "nu" %in% names(v_f) ){
y_nu = as.numeric(v_f$nu$fit[1])
y_nu_sd = as.numeric(v_f$nu$se.fit[1])
v_nu=  rnorm( numCol, y_nu, y_nu_sd)
l_m$Shape = list( 'ShapeName' = "constant", 'models' = matrix(v_nu, nrow = 1, ncol  = numCol) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'shape', ParmName =  'constant_nu'  , ParmIndex = 1, ParmValue = y_nu))
l_m$par = rbind(l_m$par, data.frame(ParmType = 'shape', ParmName =  'constant_nu_sd'  , ParmIndex = 1, ParmValue = y_nu_sd))
basisName = "level_pulse_constant_scale_shape"
d_stat$ShapeName = "constant"
} else{
l_m$Shape= list()
d_stat$ShapeName = "NULL"
}


#Include modelFamily
d_stat$basisFamily = basisName
d_stat$modelFamily = paste(basisName, "_", l_parm$distributionFamily, sep='')

#Include functions 
d_stat$basisFunction = "func.gamlss.basis.level.pulse"
d_stat$likFunction = "func.lik.pulse"

#prepare list 
l_m$basisFamily = basisName 
l_m$distributionFamily = v_family 
l_m$basisFunction = d_stat$basisFunction
l_m$likFunction = d_stat$likFunction 
l_m$data = d_y 
l_m$stat = d_stat
l_m$par$Freq = numCol
l_m$par$basisFamily = d_stat$basisFamily 
l_m$par$modelFamily = d_stat$modelFamily
l_m$residuals = fit$residuals

					
return(l_m)
} 

