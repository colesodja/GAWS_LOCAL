########### R Function to estimate model where Location  is linear step function with positive mean change and Constant Scale/Shape

func.gamlss.basis.step.positive <- function( d_y, l_parm = list() , ...){
### Input:
#d_y - dataframe of time series values y with index Time and identifier ID
#l_parm - list with parameters, including distributionFamily

###Output: List with elements
#'stat' - dataframe containing modelName, basisName, Degrees of Freedom
#'location' - list with name and matrix containing sample paths for location parameter
#'scale' -  list with name and  matrix containing sample paths for scale parameter (if exist)
#'nu' - list with name and matrix containing sample paths for nu parameter (if exist)
#'residuals' -  quantile residuals 
#'par' - dataframe with  hyperparameters

#load package 
require(gamlss)
require(changepoint)

#lookup distribution, default to Gaussian 
v_family  = ifelse(  is.null( l_parm$distributionFamily), "NO", l_parm$distributionFamily )

#Add Time Sequence 
if( length( unique(d_y$ID)) >1) {
dft = data.frame(Time= unique(d_y$Time)) 
dft$Seq = 1:nrow(dft)
d_train = merge( d_y, dft, by  = "Time")

#Aggregate 
d_data = aggregate(data  =  d_train, y ~ Seq, median)	
} else{
d_data = d_y 
d_data$Seq = 1:nrow(d_data)
}		

#check that median at end of series is significant compared to beginning and find cp
Y = log(1 +d_data$y)
x = 1:length(Y)
nTry= ceiling( .1*length(Y))
minChg =  ifelse(  is.null( l_parm$minChg), 1.1, l_parm$minChg )
smoothPct = ifelse(  is.null( l_parm$smoothPct), .25, l_parm$smoothPct)
kNeighbor = ifelse(  is.null( l_parm$kNeighbor), 20, l_parm$kNeighbor)
Mu2 =  median( tail(Y,nTry) ) 
Mu1 =  median( head(Y,nTry) )

if(  exp(Mu2-Mu1)> minChg ){
fitc = cpt.mean(Y, penalty = "None", method = "AMOC")
cpIndex = fitc@cpts[1]

#recompute means
mu1 = median( subset( d_data, Seq < cpIndex)$y )
mu2 =  median( subset( d_data, Seq >= cpIndex)$y )
cpDev = (1+mu2)/(1+mu1)

##continue if significant
if( cpIndex < length(Y) & cpDev > minChg){
#fit model 
d_data$flag = as.factor( ifelse( d_data$Seq <= cpIndex, "0", "1"))
fit = gamlss( data = d_data, y ~ flag,
                    family =v_family, control = gamlss.control(trace = FALSE) )

								
#lookup parameter estimates		
v_f = predictAll(fit,  data = d_data, se.fit = TRUE)

#produce dataframe with statistics 
numRow= l_parm$mRows
numCol = length( unique(d_y$ID))
basisName = "step_positive_constant"

d_stat = data.frame(nSeries = numCol)
d_stat$N = nrow(d_y)
d_stat$nTime = nrow(d_data)
d_stat$Deviance = deviance(fit)
d_stat$edf = ceiling(AIC(fit)-d_stat$Deviance)/2 -1  #estimates for location, scale and shape parm
d_stat$locationName = "gamlss_step_positive_"
d_stat$distributionFamily = v_family 

#produce matrix with location
l_m = list()
v_mu = v_f$mu$fit
l_m$Location = list( 'locationName' = d_stat$locationName, 'models' = matrix(v_mu, nrow = d_stat$nTime, ncol  = 1) )

#Add cp parms
l_m$par = data.frame(ParmType = 'location', ParmName =  'cp'  , ParmIndex = 1, ParmValue = cpIndex)
l_m$par = rbind(l_m$par, data.frame(ParmType = 'location', ParmName =  'shift'  , ParmIndex = 1, ParmValue = cpDev))
l_m$par = rbind(l_m$par, data.frame(ParmType = 'location', ParmName =  'mean.pre'  , ParmIndex = 1, ParmValue = mu1))

#produce matrix with scale (if exist)
if( "sigma" %in% names(v_f) ){
y_sig = as.numeric(v_f$sigma$fit[1])
y_sig_sd = as.numeric(v_f$sigma$se.fit[1])
v_sig= exp( log(rnorm( numCol, y_sig, y_sig_sd)))
l_m$Scale = list( 'ScaleName' = "constant", 'models' = matrix(v_sig, nrow = 1, ncol  = numCol) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'scale', ParmName =  'constant_sigma'  , ParmIndex = 1, ParmValue = y_sig))
#l_m$par = rbind(l_m$par, data.frame(ParmType = 'scale', ParmName =  'constant_sigma_sd'  , ParmIndex = 1, ParmValue = y_sig_sd))
d_stat$ScaleName = "constant"
} else{
l_m$Scale = list()
d_stat$ScaleName = "NULL"
}


#produce matrix with shape (if exist)
if( "nu" %in% names(v_f) ){
y_nu = as.numeric(v_f$nu$fit[1])
y_nu_sd = as.numeric(v_f$nu$se.fit[1])
v_nu=  rnorm( numCol, y_nu, y_nu_sd)
l_m$Shape = list( 'ShapeName' = "constant", 'models' = matrix(v_nu, nrow = 1, ncol  = numCol) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'shape', ParmName =  'constant_nu'  , ParmIndex = 1, ParmValue = y_nu))
#l_m$par = rbind(l_m$par, data.frame(ParmType = 'shape', ParmName =  'constant_nu_sd'  , ParmIndex = 1, ParmValue = y_nu_sd))
d_stat$ShapeName = "constant"
} else{
l_m$Shape= list()
d_stat$ShapeName = "NULL"
}

#Include modelFamily
d_stat$basisFamily = basisName
d_stat$modelFamily = paste(basisName, "_", l_parm$distributionFamily, sep='')

#Include functions 
d_stat$basisFunction = "func.gamlss.basis.step.positive"
d_stat$likFunction = "func.lik.step"

#prepare list 
l_m$basisFamily = basisName 
l_m$distributionFamily = v_family 
l_m$basisFunction = d_stat$basisFunction
l_m$likFunction = d_stat$likFunction 
l_m$data = d_y 
l_m$stat = d_stat
l_m$par$Freq = numCol
l_m$par$basisFamily = d_stat$basisFamily 
l_m$par$modelFamily = d_stat$modelFamily
l_m$residuals = fit$residuals
} else{
l_m = list()
}
} else{
l_m = list()
}

return(l_m)
} 

