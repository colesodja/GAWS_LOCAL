########### Function to generate simulations from double seasonal univariate time series model given initial parameters and innovations

func.sim.double.seasonal <- function(d_time, l_par , ...){
#lookup error
e = d_time$e

###  Pass 1 - Update lower level seasonality
#smooth%
s2_smooth = l_par$s2_smooth
d_s2 = data.frame(t_s2 = seq(1,l_par$s2_period) , s2 = l_par$s2_0) 

## update seasonal term one at a time 
d_time$s2 = NA

for( i in seq(  nrow(d_time) ) ){
#lookup season for time period 
s_period = d_time[i,]$t_s2

#get previous season 
s_prev = d_s2[s_period,]$s2

#update 
d_time$s2[i] = s_prev + s2_smooth *e[i]
d_s2[s_period,]$s2 = d_time$s2[i]
d_s2$s2 = d_s2$s2 - mean(d_s2$s2)
}


### Pass 2 - Update higher level seasonality
#lookup parm
s1_smooth = l_par$s1_smooth
d_s1 = data.frame(t_s1= seq(1,l_par$s1_period) , s1 = l_par$s1_0) 

#aggregate
d_y = aggregate(data = d_time, e ~t_s1+s1_seq, mean)

##update 
d_y$s1 = NA 

for( j in seq(  nrow(d_y) ) ){
#lookup season for time period 
s_period = d_y[j,]$t_s1

#get previous season 
s_prev = d_s1[s_period,]$s1

#update 
d_y$s1[j] = s_prev + s1_smooth *d_y$e[j]
d_s1[s_period,]$s1 = d_y$s1[j]
d_s1$s1 = d_s1$s1 - mean(d_s1$s1)
}

#join 
d_time <- merge(d_time, d_y[,c(1,2,4)], by = c('s1_seq','t_s1') )
d_time <- d_time[order(d_time$Time),]
s1 = d_time$s1 
s2 = d_time$s2
y = s1 + s2 +e

return(list('model' = "double_seasonal", 'y' = y, 's1' = s1, 's2' = s2) )
}
