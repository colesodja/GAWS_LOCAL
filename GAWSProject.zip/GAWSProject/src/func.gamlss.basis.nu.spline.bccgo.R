########### R Function to estimate gamlss using constant location, with scale and spline shape of BCCGo family

func.gamlss.basis.nu.spline.bccgo <- function( d_y, ...){
### Input:
#d_y - dataframe of time series values y with index Time and identifier ID

###Output: List with elements
#'stat' - dataframe containing modelName, basisName, Degrees of Freedom
#'location' - list with name and matrix containing sample paths for location parameter
#'scale' -  list with name and  matrix containing sample paths for scale parameter (if exist)
#'nu' - list with name and matrix containing sample paths for nu parameter (if exist)
#'residuals' -  quantile residuals 
#'par' - dataframe with  hyperparameters

#load package 
require(gamlss)
require(splines)

#add time sequence
d_y$Seq = 1:nrow(d_y)

#fit model
fit = tryCatch( gamlss( data = d_y , y ~ 1,  sigma.formula = ~ Seq,  nu.formula = ~ pb(Seq),
                 family ="BCCGo", control = gamlss.control(trace = FALSE) ), error = function(e) NULL)

if( !is.null(fit) ){
#lookup parameter estimates
v_f = predictAll(fit,  data = d_y)

#produce dataframe with statistics 
numRow = length(unique(d_y$Time))
numCol = length( unique(d_y$ID))
basisName = "spline_shape_bccgo"

d_stat = data.frame(nSeries = numCol)
d_stat$N = nrow(d_y)
d_stat$nTime = length(unique(d_y$Time))
d_stat$Deviance = deviance(fit)
d_stat$edf = ceiling(AIC(fit)-d_stat$Deviance)/2 
d_stat$locationName = "constant"
d_stat$distributionFamily = "BCCGo"

#produce matrix with location
l_m = list()
v_mu = head( v_f$mu, 1)
l_m$Location = list( 'locationName' = d_stat$locationName, 'models' = matrix(v_mu, nrow =1, ncol  = 1) )
l_m$par = data.frame(ParmType = 'location', ParmName =  'constant'  , ParmIndex = 1, ParmValue = v_mu)

#sigma
y_sig = as.numeric(v_f$sigma)[1]
l_m$Scale = list( 'ScaleName' = "constant", 'models' = matrix(y_sig, nrow = 1, ncol  = numCol) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'scale', ParmName =  'constant'  , ParmIndex = 1, ParmValue = y_sig))
d_stat$ScaleName = "constant"

#produce matrix with shape 
y_nu = as.numeric(v_f$nu)
l_m$Shape = list( 'ShapeName' = "constant", 'models' = matrix(y_nu, nrow = d_stat$nTime, ncol  = 1) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'shape', ParmName =  'nu_basis_pbz'  ,ParmIndex = 1, ParmValue = y_nu))
d_stat$ShapeName = "cubic_spline"

#Include modelFamily
d_stat$basisFamily = basisName
d_stat$modelFamily = paste(basisName, "_", "BCCGo" , sep='')

#Include functions 
d_stat$basisFunction = "func.gamlss.basis.nu.spline.bccgo"
d_stat$likFunction = "func.lik.iid"

#prepare list 
l_m$basisFamily = basisName 
l_m$distributionFamily = "BCCGo"
l_m$basisFunction = d_stat$basisFunction
l_m$likFunction = d_stat$likFunction 
l_m$data = d_y 
l_m$stat = d_stat
l_m$par$Freq = numCol
l_m$par$basisFamily = d_stat$basisFamily 
l_m$par$modelFamily = d_stat$modelFamily
}  else{
l_m = list()
}

#return list
return(l_m)
}

