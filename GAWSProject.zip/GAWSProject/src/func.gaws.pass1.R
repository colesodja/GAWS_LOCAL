############# GAMLSS-AKAIKE-WEIGHTS-SCORING  R Function - Univariate Series Loop 1 Pass
## Description:
#Assumes all needed packages are installed
#Assumes data is sufficiently small enough to fit in memory and amenable for running the RS-algorithm
#Assumes all functions are already sourced
 #dependent on: func.akaike.weights
 #dependent on class of functions with abbreviations "func.gamlss.basis."

## Input: 
#dfy - dataframe of time series values y with index Time and identifier ID
#l_Family - list of bases families arguments
#maxRank  - scalar defining the maximum number of time series to return based on ranking of lowest likelihood scores

## Output: dataframe with relative likelioood scores per each time series, rank, and score


func.gaws.pass1  <- function( dfy, l_Family,  maxRank , printON = FALSE , ...){
#packages 
require(gamlss)
require(sqldf)

#list of time series 
v_j = unique(dfy$ID)


#lookup basis function names
l_b = l_Family$l_bases
v_bases = names(l_b)

#minimum relative likelihood to be considered a potential model
minLik = ifelse( is.null( l_Family$parm$minLik), 1/1000,  l_Family$parm$minLik)

#dataframe for appending likelihood
d_lik = data.frame()

### PART 1 -  1st Time Series Loop to compute relative likelihood per series
for( j in v_j ){

if( printON ){
  print(j)
 } 
  
  #subset to time series and build dataframe
  d_y = subset(dfy, ID == j)
  d_m_s = data.frame()
 
 ## loop thru each modelFamily (could also be distributed)
  for( b in v_bases ){
    #subset to basis info 
    pos = which( v_bases == b)
    l_info = l_b[[pos]]
    l_info$basisFamily = b
    
    #create list of parameters 
    l_parm = c(l_Family$parm,  list('distributionFamily' = l_info$distributionFamily), l_info$arg)
    
    #run model (ignoring any error if raised)
    l_m = tryCatch( get(l_info$basisFunction)( d_y, l_parm), error = function(e) list() ) 
	
	#append if exists
	if( length(l_m) >0){
	d_s = l_m$stat 
	d_s$ID = j
	d_s$isNormal = l_info$isNormal
	d_m_s = rbind(d_m_s, d_s)
   }	

  } #end of models loop
  
  
#compute Akaike weights 
d_wt  = func.akaike.weights( d_m_s, penalty = log(nrow(d_y) ) ) 

# append
d_lik =   rbind( d_lik , d_wt )
} #end of time series loop


### PART 2 - Compute Akaike Scores|isNormal == "Y"  
#Lookup all series 
d_score = data.frame( Col = v_j)

#subset to isNormal modelFamily and compute total Akaike Weight per series 
d_normal = subset(d_lik, isNormal == 'Y')
d_normal = sqldf('Select ID as Col, sum(rel_lik) as Score from d_normal group by 1')

#Join and rank 
d_score = merge(x = d_score, y = d_normal, by = 'Col')
d_score$Score = ifelse( is.na(d_score$Score), 0, d_score$Score)
d_score = d_score[order(d_score$Score),]
d_score$Rank = 1:nrow(d_score)
d_score$Method = "gaws"

#return dataframe
return(d_score)
}

