########### R Function to estimate gamlss where Location and Scale are constant and Shape has pbm spline, using BCCGo family

func.gamlss.basis.shape.trend <- function( d_y, ...){
### Input:
#d_y - dataframe of time series values y with index Time and identifier ID

###Output: List with elements
#'stat' - dataframe containing modelName, basisName, Degrees of Freedom
#'location' - list with name and matrix containing sample paths for location parameter
#'scale' -  list with name and  matrix containing sample paths for scale parameter (if exist)
#'nu' - list with name and matrix containing sample paths for nu parameter (if exist)
#'residuals' -  quantile residuals 
#'par' - dataframe with  hyperparameters

#load package 
require(gamlss)
require(splines)

#add time sequence
d_y$Seq = 1:nrow(d_y)
d_y$X = ifelse( d_y$Seq > 300,1,0)

#add flag for anomaly at 457
d_y$flag = ifelse( d_y$Seq == 457,1,0) 

#estimate
fit = gamlss( data = d_y , y ~1+flag, nu.formula = ~ X, family ="BCCGo", control = gamlss.control(trace = FALSE) )

#lookup parameter estimates
v_f = predictAll(fit,  data = d_y)

#produce dataframe with statistics 
numRow=1
numCol = length( unique(d_y$ID))
basisName = "constant_location_scale_trend_shape"

d_stat = data.frame(nSeries = numCol)
d_stat$N = nrow(d_y)
d_stat$nTime = length(unique(d_y$Time))
d_stat$Deviance = deviance(fit)
d_stat$edf = 3
d_stat$locationName = "constant"
d_stat$distributionFamily = "BCCGo"

#produce matrix with location
l_m = list()
v_mu = head( v_f$mu, d_stat$nTime)
l_m$Location = list( 'locationName' = d_stat$locationName, 'models' = matrix(v_mu, nrow = d_stat$nTime, ncol  = 1) )

#sigma
y_sig = as.numeric(v_f$sigma)
v_sig= head(y_sig, numCol)
l_m$Scale = list( 'ScaleName' = "constant", 'models' = matrix(v_sig, nrow = 1, ncol  = numCol) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'scale', ParmName =  'constant_sigma'  , ParmIndex = 1, ParmValue = y_sig))
d_stat$ScaleName = "spline"

#produce matrix with shape 
y_nu = as.numeric(v_f$nu[1])
l_m$Shape = list( 'ShapeName' = "constant", 'models' = matrix(y_nu, nrow = 1:length(y_nu), ncol  = 1) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'shape', ParmName =  'constant_nu'  ,ParmIndex = 1, ParmValue = y_nu))
d_stat$ShapeName = "spline"

#Include modelFamily
d_stat$basisFamily = paste(basisName, "_", "_series",unique(d_y$ID) , sep='')
d_stat$modelFamily = paste(basisName, "_", "BCCGo", "_series",unique(d_y$ID) , sep='')

#Include functions 
d_stat$basisFunction = "func.gamlss.basis.shape.trend"
d_stat$likFunction = "func.lik.shape.trend.bccgo"

#prepare list 
l_m$basisFamily = basisName 
l_m$distributionFamily = "BCCGo"
l_m$basisFunction = d_stat$basisFunction
l_m$likFunction = d_stat$likFunction 
l_m$data = d_y 
l_m$stat = d_stat
l_m$par$Freq = numCol
l_m$par$basisFamily = d_stat$basisFamily 
l_m$par$modelFamily = d_stat$modelFamily
l_m$residuals = fit$residuals

return(l_m)
} 

