########### R Function to estimate gamlss with following parameters and TF Distribution Family
 #Location: overfit spline 
 # Scale: spline of degree 5
 # Shape: Constant

func.gamlss.traffic.location.spline.scale.spline <- function( d_y, ...){
### Input:
#d_y - dataframe of time series values y with index Time and identifier ID

###Output: List with elements
#'stat' - dataframe containing modelName, basisName, Degrees of Freedom
#'location' - list with name and matrix containing sample paths for location parameter
#'scale' -  list with name and  matrix containing sample paths for scale parameter (if exist)
#'nu' - list with name and matrix containing sample paths for nu parameter (if exist)
#'residuals' -  quantile residuals 
#'par' - dataframe with  hyperparameters

#load package 
require(gamlss)
require(splines)

#add time sequence
d_y$Seq = 1:nrow(d_y)

#fit linear spline bases of high degree
fits = lm( data = d_y, y ~ bs( Seq, degree=1, df = 100) )
yhat = as.numeric(predict(fits))

#Get residuals and flag extreme
Y = d_y$y
z = Y - yhat
z = z/mad(z)

x_pulse = as.factor( ifelse( abs(z) > 10, d_y$Seq ,0))

if( length(unique(x_pulse))==1 ){
      x_pulse = as.factor( ifelse( Y == max(Y),1,0 ))
}
    

##fit gamlss 
dfx = data.frame( Y,yhat, x_pulse, Seq = d_y$Seq)
fit = gamlss(data = dfx, 
               Y ~ yhat+ x_pulse, 
			    sigma.formula = ~ pb(Seq, degree=1, df=5),
               family = "TF" ,
			   control = gamlss.control(trace = FALSE)
)


#lookup parameter estimates
v_f = predictAll(fit,  data = dfx)

#produce dataframe with statistics 
numRow = nrow(d_y)
numCol = length( unique(d_y$ID))
basisName = "traffic_spline_spline_constant"

d_stat = data.frame(nSeries = numCol)
d_stat$N = nrow(d_y)
d_stat$nTime = length(unique(d_y$Time))
d_stat$Deviance = deviance(fit)
d_stat$edf =100+5+1
d_stat$locationName = "spline"
d_stat$distributionFamily = "TF"

#produce matrix with location
l_m = list()
l_m$Location = list( 'locationName' = d_stat$locationName, 'models' = matrix(v_f$mu, nrow = numRow, ncol  = 1) )
l_m$par = data.frame(ParmType = 'location', ParmName =  'basis' , ParmIndex = 1, ParmValue = v_f$mu)

#sigma
y_sig = as.numeric(v_f$sigma)
l_m$Scale = list( 'ScaleName' = "constant", 'models' = matrix(y_sig, nrow = numRow, ncol  = numCol) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'scale', ParmName =  'basis'  , ParmIndex = 1, ParmValue = y_sig))
d_stat$ScaleName = "spline"

#produce matrix with shape 
y_nu = as.numeric(v_f$nu)[1]
l_m$Shape = list( 'ShapeName' = "constant", 'models' = matrix(y_nu, nrow = 1, ncol  = 1) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'shape', ParmName =  'basis'  ,ParmIndex = 1, ParmValue = y_nu))
d_stat$ShapeName = "constant"

#Include modelFamily
d_stat$basisFamily = basisName
d_stat$modelFamily = paste(basisName, "_", "log-TF" , sep='')

#Include functions 
d_stat$basisFunction = "func.gamlss.traffic.location.spline.scale.spline"
d_stat$likFunction = "func.lik.basis.traffic"

#prepare list 
l_m$basisFamily = basisName 
l_m$distributionFamily = "TF"
l_m$basisFunction = d_stat$basisFunction
l_m$likFunction = d_stat$likFunction 
l_m$data = d_y 
l_m$stat = d_stat
l_m$par$Freq = numCol
l_m$par$basisFamily = d_stat$basisFamily 
l_m$par$modelFamily = d_stat$modelFamily

#return list
return(l_m)
} 

