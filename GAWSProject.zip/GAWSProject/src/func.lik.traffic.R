
############# Computes Penalized Deviance given location, scale, shape parameters
## Input: 
#d_y - dataframe of univariate time series values y with index Time and identifier ID
#d_basis0 is a dataframe containing ParmName, ParmIndex, Freq, ParmValue, modelFamily for "normal" models in the basis
# d_basis1 is a dataframe containing ParmName, ParmIndex, Freq, ParmValue,modelFamily for "alternative" model in the basis
# penalty is a scalar value defining how much to penalize model complexityy
#l_parm is a list with arguments, including distributionFamily

## Output: dataframe with the penalized deviances and model likelihood|modelFamily

func.lik.traffic <- function( d_y, d_basis0, d_basis1, l_parm, penalty,  ...) {
#load package
require(gamlss)

#extract time series 
y = d_y$y

#create name of likelihood function 
fLik = paste("d",l_parm$distributionFamily,sep='') 
modelFamily = unique(d_basis0$modelFamily)

##lookup parameters for alternative 
Mu_1 = subset(d_basis1, ParmType == "location" & ParmName == "basis" )$ParmValue
Sig_1 =  subset(d_basis1, ParmType == "scale"  & ParmName == "basis")$ParmValue
Nu_1 = subset(d_basis1, ParmType == "shape"  & ParmName == "basis")$ParmValue
vDF_1 = unique(d_basis1$edf)


##function to compute NLL 
func.nll1 = function(  Mu, Sigma, Nu ){
if( all( !is.na(Nu) ) ){
NLL = sum(  get(fLik)(y, mu = Mu, sigma = Sigma, nu = Nu, log = TRUE) )
} else{
NLL = sum(  get(fLik)(y, mu = Mu, sigma = Sigma, log = TRUE) )
}
return(NLL)
}


#Compute NLL and PL for alternative 
NLL_1 = func.nll1( Mu_1, Sig_1, Nu_1)
d_m_lik =data.frame( isNormal = "?", NLL = NLL_1, edf = vDF_1, Deviance = -2*NLL_1 )
d_m_lik$penLik = d_m_lik$Deviance + penalty *d_m_lik$edf
d_m_lik$modelID = paste(modelFamily, "_Series_", j, sep='') 

### loop thru every other model and compute 
v_mid = unique(d_basis0$modelID)

for( m in v_mid){
#subset to model and lookup parm 
dfm = subset(d_basis0, modelID == m)
Mu_0 =  subset(dfm, ParmType == "location")$ParmValue
Sig_0 =  subset(dfm, ParmType == "scale")$ParmValue
Nu_0 = subset(dfm, ParmType == "shape")$ParmValue
vDF_0 = unique(dfm$edf)

#calc 
NLL_0 = func.nll1( Mu_0, Sig_0, Nu_0)
Deviance_0 = -2*NLL_0
penLik = Deviance_0 + penalty*vDF_0 

#append 
d_m0 = data.frame(  isNormal = "Y", NLL = NLL_0, edf = vDF_0, Deviance = Deviance_0, penLik, modelID = m )
d_m_lik = rbind(d_m_lik, d_m0)
}

#format data
j = unique(d_y$ID)
d_m_lik$ID = j
d_m_lik$modelFamily = modelFamily
d_m_lik$distributionFamily = l_parm$distributionFamily
#d_m_lik$subspaceId = c( paste(modelFamily, "_Prior", sep=''),  paste(modelFamily, "_Series_", j, sep='')  )

#output dataframe 
return(d_m_lik)
}
