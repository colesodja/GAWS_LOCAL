########### R Function to estimate gamlss with following parameters and TF Distribution Family
 #Location:  multiple seasonality using indicators and level shift
 # Scale: Constant
 # Shape: Constant

func.gamlss.tf.hour.dow.shift <- function( d_y, ...){
### Input:
#d_y - dataframe of time series values y with index Time and identifier ID

###Output: List with elements
#'stat' - dataframe containing modelName, basisName, Degrees of Freedom

#load package 
require(gamlss)
require(splines)
require(MASS)
require(forecast)


#create factor variables for Day of Week and Hour of Day
d_y$fDow = as.factor(d_y$Dow)
d_y$fHour = as.factor(d_y$Hour)

## Model 1: Seasonality 
fits = rlm( data = d_y, y ~ fDow*fHour)
S = predict(fits)
S = S-mean(S)

## Model 2: Level as temporary positive shift
L = d_y$y - S

#fit local level with fixed smoothing
fitl = ets(L, model="ANN", opt.crit = "mae", alpha = .2)
z = fitted(fitl)
z  = z - median(z)

#Look for last location where transition from negative to positive 
posNeg = max( which(z <= .001) )
v_Pos = which( z > .01)
v_Pos = v_Pos[v_Pos > posNeg]

#compute robust dev 
x = 1:length(z)
z_pre = z[ x < min(v_Pos) ]
z_sd = 1.5*median(abs(z_pre))

#Compute diff and select where above 1 sigma
z_post = z[ v_Pos]
v_diff = c(0, diff(z_post))
xCP = which( v_diff >= z_sd)[1]
xCP = v_Pos[xCP]

#lookup last positive after cp 
xEnd = max(v_Pos)
xlevelShift = seq(xCP, xEnd)

##fit gamlss model 
chgPoint = ifelse( x %in% xlevelShift,1,0)
z_post = z[chgPoint==1]
dfx = data.frame( y = d_y$y, S, chgPoint)

if( length( xlevelShift) >=3 & length(xlevelShift) <= 24 &  exp( mean(z_post) -mean(z_pre )) > 1.1 ){
fit = gamlss(data = dfx, y ~ S+chgPoint , family = "TF" , control = gamlss.control(trace = FALSE))
} else{
fit = gamlss(data = dfx, y ~ S, family = "TF" , control = gamlss.control(trace = FALSE))
}

#Compute statistics and output
d_stat = data.frame(N = nrow(d_y))
d_stat$Deviance = deviance(fit)
d_stat$edf = 3 + length(coef(fits))
d_stat$modelFamily = "log_tf_season_shift"

#Output list 
l_m = list()
l_m$stat = d_stat

#return list
return(l_m)
} 

