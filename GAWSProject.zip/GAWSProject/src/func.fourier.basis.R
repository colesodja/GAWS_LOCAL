########### Function to compute/return Fourier basis given known list of coefficients for sine and cosine and known period


func.fourier.basis <- function( l_par,  s.period, ...){
#create time sequence given period length
v_time = seq(s.period)

#extract coeff 
coef_sin =  l_par$v_coef_sine
coef_cos =  l_par$v_coef_cosine

if( !(length(coef_sin) ==length( coef_cos )) ) {
stop("cannot compute fourier basis using different coef length")
} 

K = length(coef_sin)

## loop through each time sequence and comput basis
v_basis = c()

for(  i in v_time) {
 v = c()

 for( k in seq(K) ){
  a = coef_sin[k]
  b = coef_cos[k]
  v = c(v,  a*sin(2*pi*k*i/s.period) +  b*cos(2*pi*i*k/s.period)  )
 }
 
  v_basis = c(v_basis ,sum(v))
}

return(v_basis)
}
