############# Computes the excess rank performance measure  per each method 

## Input: 
#d_rank - dataframe containing Col (identifier of time series), Rank (lower -> anomaly), Method (name of anomaly detector), isAnomaly
#maxRank  - scalar defining the maximum number of time series to return as anomalous

## Output: dataframe with fscore per method

func.fscore <- function( d_rank, maxRank ){
#find anomalies 
v_AnomalyIndex = unique( subset(d_rank, isAnomaly==1)$Col)

#subset per rank 
d_r = subset(d_rank, Rank <= maxRank)

#compute tp, fp, fn per method 
d_fscore = data.frame()
v_M = unique(d_rank$Method)

for( v in v_M){
dfv = subset(d_r, Method == v)
dfs = data.frame( TP =sum( ifelse(dfv$isAnomaly==1,1,0)), FP = sum(ifelse(dfv$isAnomaly==0,1,0)))
dfs$FN = length( which( !(v_AnomalyIndex %in% dfv$Col)  ) )
dfs$Method = v 
d_fscore  = rbind(d_fscore , dfs)
} 

d_fscore$Precision = d_fscore$TP/( d_fscore$TP +  d_fscore$FP)
d_fscore$Recall = d_fscore$TP/( d_fscore$TP +  d_fscore$FN)
d_fscore$fScore = 2*(d_fscore$Precision*d_fscore$Recall)/(d_fscore$Precision+d_fscore$Recall)

return(d_fscore)
}

