############# GAMLSS-AKAIKE-WEIGHTS-SCORING  R Function - Univariate Series Looping
## Description:
#Assumes all needed packages are installed
#Assumes data is sufficiently small enough to fit in memory and amenable for running the RS-algorithm
#Assumes all functions are already sourced
 #dependent on: func.akaike.weights
 #dependent on class of functions with abbreviations "func.gamlss.basis."

## Input: 
#dfy - dataframe of time series values y with index Time and identifier ID
#l_Family - list of bases families arguments
#maxRank  - scalar defining the maximum number of time series to return based on ranking of lowest likelihood scores

## Output: dataframe with relative likelioood scores per each time series, rank, and score

func.gaws.univariate.loop <- function( dfy, l_Family,  maxRank , printON = FALSE , ...){
#packages 
require(gamlss)
require(sqldf)

#lookup basis function names
l_b = l_Family$l_bases
v_bases = names(l_b)

#dataframes for appending
d_model = data.frame()

### Time Series Loop (should be ran in cloud distributed!)
v_j = unique(dfy$ID)

for( j in v_j ){

if( printON ){
  print(j)
 } 
  
  #subset to time series and build dataframe
  d_y = subset(dfy, ID == j)
  
  #create objects to save info
  d_m = data.frame() #append models stat to dataframe 
 
 ## loop thru each modelFamily (could also be distributed)
  for( b in v_bases ){
    #subset to basis info 
    pos = which( v_bases == b)
    l_info = l_b[[pos]]
    l_info$basisFamily = b
    
    #create list of parameters 
    l_parm = c(l_Family$parm,  list('distributionFamily' = l_info$distributionFamily), l_info$arg)
    
    #run model (ignoring any error if raised)
    l_m = tryCatch( get(l_info$basisFunction)( d_y, l_parm), error = function(e) list() ) 
	
	#append if exists
	if( length(l_m) >0){
    d_m= rbind(d_m, l_m$stat)
   }	

  } #end of models loop
  
  ## Compute Akaike Weights and subset
  if( nrow(d_m)>0){
  d_m$ID = j
  d_lik  = func.akaike.weights( d_m, penalty = log(nrow(d_y) ) )
  d_lik$modelID = paste(d_lik$modelFamily,"_",j, sep='')
  d_model = rbind(d_model, d_lik)
  }
  
} #end of time series loop


#lookup minumum number of unique time series per subspace 
minLik = ifelse( is.null( l_Family$parm$minLik), 1/1000,  l_Family$parm$minLik)
minObsSubspace =  ifelse( is.null( l_Family$parm$minObsSubspace), pmax(10,.01*length(v_j)),   l_Family$parm$minObsSubspace )

#form probable subspaces per basisFamily
d_subspace = subset(d_model, rel_lik > minLik )
d_subspace = sqldf('Select basisFamily, count(distinct ID) as N from d_subspace group by 1')

#assign "normal" subspaces as having minimum frequency
d_subspace  = subset(d_subspace, N >= minObsSubspace)
d_subspace$likSubspace = d_subspace$N/sum(d_subspace$N)

#compute probability of each subspace per ID and rank
if( nrow(d_subspace) >0 ){
d_score = merge(d_model, d_subspace, by = "basisFamily")
d_score$weightLik = d_score$rel_lik * d_score$likSubspace
d_score = sqldf('Select ID as Col, sum(rel_lik) as Prob,  sum(weightLik) as wtProb from d_score group by 1 order by 3')
d_score$Rank = 1:nrow(d_score)
} else{
d_score = d_model
v_mod = unique(d_score$basisFamily)
v_mod = v_mod[grepl("series",v_mod) == FALSE]
d_score   = subset(d_score , basisFamily %in% v_mod)
d_score = sqldf('Select ID as Col, sum(rel_lik) as Prob from d_score group by 1 order by 2 desc')
d_score$Rank = 1:nrow(d_score)
}

#subset to scores below minimum likelihood threshold 
#d_score =  subset(d_score, Prob <= minLik)

#return dataframe
return(d_score)
}
