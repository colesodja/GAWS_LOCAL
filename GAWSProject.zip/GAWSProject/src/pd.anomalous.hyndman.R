########### Function to Call Rob Hyndman's anomalous package and anomaly function

pd.anomalous.hyndman <- function( Y1, X = NULL, numAlarm = 1 , ...){
#load package 
require(anomalous)

#compute features of time series
Z1 <- tsmeasures(Y1)

#Z1 <- Z1[, c(1:5, 7:12) ]

#find anomalous time series features 
A <- anomaly( Z1, n = numAlarm , plot = FALSE)

#return dataframe with ranking, column index, and model_name 
dm <- data.frame( Rank = 1:numAlarm, Col = A$index, Model = 'pca+hdr', Score = NA)

} 