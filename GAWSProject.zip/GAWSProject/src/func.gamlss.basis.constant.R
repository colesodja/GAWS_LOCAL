########### R Function to estimate iid constant location, scale, shape model given specified distribution

func.gamlss.basis.constant <- function( d_y, l_parm , ...){
### Input:
#d_y - dataframe of time series values y with index Time and identifier ID
#l_parm - list with parameters, including distributionFamily

###Output: List with elements
#'stat' - dataframe containing modelName, basisName, Degrees of Freedom
#'location' - list with name and matrix containing sample paths for location parameter
#'scale' -  list with name and  matrix containing sample paths for scale parameter (if exist)
#'nu' - list with name and matrix containing sample paths for nu parameter (if exist)
#'residuals' -  quantile residuals 
#'par' - dataframe with  hyperparameters

#load package 
require(gamlss)

#lookup distribution, default to Gaussian 
v_family  = ifelse(  is.null( l_parm$distributionFamily), "NO", l_parm$distributionFamily )

#fit model 
fit = gamlss( data = d_y, y ~1, family = v_family, control = gamlss.control(trace = FALSE) ) 		

#lookup parameter estimates
v_f = predictAll(fit,  data = d_y, se.fit = TRUE)

#produce dataframe with statistics 
numRow= l_parm$mRows
numCol = length( unique(d_y$ID))
basisName = "constant_location"

d_stat = data.frame(nSeries = numCol)
d_stat$N = nrow(d_y)
d_stat$nTime = length(unique(d_y$Time))
d_stat$Deviance = deviance(fit)
d_stat$edf = ceiling(AIC(fit)-d_stat$Deviance)/2   #estimates for location, scale and shape parm
d_stat$locationName = "constant"
d_stat$distributionFamily = v_family 

#produce matrix with location, drawing from Gaussian
l_m = list()
y_mu = as.numeric(v_f$mu$fit[1])
y_mu_sd = as.numeric(v_f$mu$se.fit[1])
v_mu = rnorm( numCol, y_mu, y_mu_sd)

l_m$Location = list( 'locationName' = "constant", 'models' = matrix(v_mu, nrow = 1, ncol  = numCol) )
l_m$par = data.frame(ParmType = 'location', ParmName =  'constant_mu' , ParmIndex = 1, ParmValue = y_mu)
l_m$par = rbind(l_m$par, data.frame(ParmType = 'location', ParmName =  'constant_mu_sd'  , ParmIndex = 1, ParmValue = y_mu_sd))

#produce matrix with scale (if exist)
if( "sigma" %in% names(v_f) ){
y_sig = as.numeric(v_f$sigma$fit[1])
y_sig_sd = as.numeric(v_f$sigma$se.fit[1])
v_sig= exp( log(rnorm( numCol, y_sig, y_sig_sd)))
l_m$Scale = list( 'ScaleName' = "constant", 'models' = matrix(v_sig, nrow = 1, ncol  = numCol) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'scale', ParmName =  'constant_sigma'  , ParmIndex = 1, ParmValue = y_sig))
l_m$par = rbind(l_m$par, data.frame(ParmType = 'scale', ParmName =  'constant_sigma_sd'  , ParmIndex = 1, ParmValue = y_sig_sd))
basisName = "constant_location_scale"
d_stat$ScaleName = "constant"
} else{
l_m$Scale = list()
d_stat$ScaleName = "NULL"
}


#produce matrix with shape (if exist)
if( "nu" %in% names(v_f) ){
y_nu = as.numeric(v_f$nu$fit[1])
y_nu_sd = as.numeric(v_f$nu$se.fit[1])
v_nu=  rnorm( numCol, y_nu, y_nu_sd)
l_m$Shape = list( 'ShapeName' = "constant", 'models' = matrix(v_nu, nrow = 1, ncol  = numCol) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'shape', ParmName =  'constant_nu'  , ParmIndex = 1, ParmValue = y_nu))
l_m$par = rbind(l_m$par, data.frame(ParmType = 'shape', ParmName =  'constant_nu_sd'  , ParmIndex = 1, ParmValue = y_nu_sd))
basisName = "constant_location_scale_shape"
d_stat$ShapeName = "constant"
} else{
l_m$Shape= list()
d_stat$ShapeName = "NULL"
}

#Include modelFamily
d_stat$basisFamily = basisName
d_stat$modelFamily = paste(basisName, "_", l_parm$distributionFamily, sep='')

#Include functions 
d_stat$basisFunction = "func.gamlss.basis.constant"
d_stat$likFunction = "func.lik.iid"

#return list 
l_m$basisFamily = basisName 
l_m$distributionFamily = v_family 
l_m$basisFunction = "func.gamlss.basis.constant"
l_m$likFunction = "func.lik.iid"
l_m$data = d_y 
l_m$stat = d_stat
l_m$par$Freq = numCol
l_m$par$basisFamily = d_stat$basisFamily 
l_m$par$modelFamily = d_stat$modelFamily
l_m$residuals = fit$residuals
return(l_m)
} 

