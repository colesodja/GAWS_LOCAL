########### R Function to estimate daily/weekly seasonality for location and Constant Scale/Shape

func.gamlss.basis.level.seas <- function( d_y, l_parm , ...){
### Input:
#d_y - dataframe of time series values y with index Time and identifier ID
#l_parm - list with parameters, including distributionFamily

###Output: List with elements
#'stat' - dataframe containing modelName, basisName, Degrees of Freedom
#'location' - list with name and matrix containing sample paths for location parameter
#'scale' -  list with name and  matrix containing sample paths for scale parameter (if exist)
#'nu' - list with name and matrix containing sample paths for nu parameter (if exist)
#'residuals' -  quantile residuals 
#'par' - dataframe with  hyperparameters

#load package 
require(gamlss)

#lookup distribution, default to Gaussian 
v_family  = ifelse(  is.null( l_parm$distributionFamily), "NO", l_parm$distributionFamily )

#create day of week and hour of day indicators
d_y$Hour = as.integer(  strftime(d_y$Time,format = '%H') )
d_y$Dow = as.integer(  strftime(d_y$Time,format = '%w') )

#aggregate and check hour is significant before running gamlss (to speed up based on iterations)
d_y$z = log(1+d_y$y)
fit1 = lm(data = d_y, z ~  1)
fit2 = lm(data = d_y, z ~  1 + as.factor(d_y$Hour) + as.factor(d_y$Dow) )  

#fit model 
if( BIC(fit2) < BIC(fit1) ){
fit = gamlss( data = d_y, y ~ 1+ cs(Dow,df=5) + cs(Hour,df=10) , 
                    family =v_family, control = gamlss.control(trace = FALSE) )
} else{
fit = gamlss( data = d_y, y ~ 1 + as.factor(d_y$Hour) + as.factor(d_y$Dow), 
                    family =v_family, control = gamlss.control(trace = FALSE) )
}					
		
#lookup parameter estimates	
d_data = unique(d_y[,c('Time','Dow','Hour')])				
v_f = predictAll(fit,  data = d_data)

#produce dataframe with statistics 
numRow= l_parm$mRows
numCol = length( unique(d_y$ID))
basisName = "level_seas_constant"

d_stat = data.frame(nSeries = numCol)
d_stat$N = nrow(d_y)
d_stat$nTime = length(unique(d_y$Time))
d_stat$Deviance = deviance(fit)
d_stat$edf = ceiling(AIC(fit)-d_stat$Deviance)/2 +1  #estimates for location, scale and shape parm
d_stat$locationName = "gamlss_level_seas_"
d_stat$distributionFamily = v_family 

#produce matrix with location
l_m = list()
v_mu = v_f$mu
l_m$Location = list( 'locationName' = d_stat$locationName, 'models' = matrix(v_mu, nrow = d_stat$nTime, ncol  = 1) )

#lookup seasonality terms 
v_s = tryCatch( predict(fit,  data = d_data, type="terms"), error = function(e) NULL)
if( is.null(v_s) ){
l_m$par = data.frame(ParmType = 'location', ParmName =  's_dow'  , ParmIndex = 1, ParmValue = NA)
l_m$par = rbind(l_m$par, data.frame(ParmType = 'location', ParmName =  's_hour'  , ParmIndex = 1, ParmValue = NA))

} else{
d_data$S_dow = v_s[,1]
d_data$S_hour = v_s[,2]
s_dow = aggregate(data = d_data, S_dow ~ Dow, mean)[,2]
s_hour = aggregate(data = d_data, S_hour ~ Hour, mean)[,2]

l_m$par = data.frame(ParmType = 'location', ParmName =  's_dow'  , ParmIndex = 1:length(s_dow), ParmValue = s_dow)
l_m$par = rbind(l_m$par, data.frame(ParmType = 'location', ParmName =  's_hour'  , ParmIndex = 1:length(s_hour), ParmValue = s_hour))
}


#produce matrix with scale (if exist)
if( "sigma" %in% names(v_f) ){
y_sig = as.numeric(v_f$sigma[1])
l_m$Scale = list( 'ScaleName' = "constant", 'models' = matrix(y_sig, nrow = 1, ncol  = numCol) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'scale', ParmName =  'constant_sigma'  , ParmIndex = 1, ParmValue = y_sig))
basisName = "level_seas_constant_scale"
d_stat$ScaleName = "constant"
} else{
l_m$Scale = list()
d_stat$ScaleName = "NULL"
}

#produce matrix with shape (if exist)
if( "nu" %in% names(v_f) ){
y_nu = as.numeric(v_f$nu[1])
l_m$Shape = list( 'ShapeName' = "constant", 'models' = matrix(y_nu, nrow = 1, ncol  = numCol) )
l_m$par = rbind(l_m$par, data.frame(ParmType = 'shape', ParmName =  'constant_nu'  , ParmIndex = 1, ParmValue = y_nu))
basisName = "level_seas_constant_scale_shape"
d_stat$ShapeName = "constant"
} else{
l_m$Shape= list()
d_stat$ShapeName = "NULL"
}

#Include modelFamily
d_stat$basisFamily = basisName
d_stat$modelFamily = paste(basisName, "_", l_parm$distributionFamily, sep='')

#Include functions 
d_stat$basisFunction = "func.gamlss.basis.level.seas"
d_stat$likFunction = "func.lik.seas"

#return list 
l_m$basisFamily = basisName 
l_m$distributionFamily = v_family 
l_m$basisFunction = d_stat$basisFunction
l_m$likFunction = d_stat$likFunction 
l_m$data = d_y 
l_m$stat = d_stat
l_m$par$Freq = numCol
l_m$par$basisFamily = d_stat$basisFamily 
l_m$par$modelFamily = d_stat$modelFamily
l_m$residuals = fit$residuals

return(l_m)
} 

